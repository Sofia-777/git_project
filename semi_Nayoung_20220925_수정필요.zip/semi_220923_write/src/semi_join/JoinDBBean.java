package semi_join;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import semi_board.BoardBean;
import semi_board.BoardDBBean;



public class JoinDBBean {
	// 작성자 : 김나영 
	// 날짜 : 2022.09.22 ~ 09.25
	//한글 깨진 현상 발생
	//패들렛의 언니들의 정리본 보면서 작성했어요!!!
	//( 제건..... 강사님 소스 사용하고 있구 아마 빠진 설명 빠진 부분이 많아서..믿을 수가 없어요)
	
	
	
	private static JoinDBBean instance = new JoinDBBean();
	//전역 joinBean 객체 레퍼런스를 리턴하는 메소드
	public static JoinDBBean getInstance() {
		return instance;
	}
	
//	쿼리 작업에 사용할 커넥션 객체를 리턴하는 메소드
	public Connection getConnection() throws Exception {
		Context ctx = new InitialContext();
		DataSource ds = (DataSource)ctx.lookup("java:comp/env/jdbc/oracle");
		return ds.getConnection();
	}
	
//	전달인자로 받은 join을 SEMI_JOINTABLE에 삽입하는 insertJoin 메소드(글 삽입)
	public int insertJoin(JoinBean join) throws Exception{
		int re = -1;
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql="SELECT MAX(j_idx) FROM SEMI_JOINTABLE";
		//글 번호 순서를 위한 쿼리. 글 번호 중 제일 큰 값을 찾음
		int number=1;
		// 1로 시작해야지 테이블에 데이터가 없을때 번호 1이 부여됨.
		
		int nowmem=join.getJ_nowmem();
		//현재 인원(최소 1명=작성자)를 표기 하기 위해서 join 전달인자를 받아서 하려고 하였음
		int idx = join.getJ_idx();
		// 위의 idx는 원래 답글 표기하기 위해서 사용하는 코드 중 하나인듯함
		//일단 삭제 시도
		
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			//최대값을 찾은 결과 rs에 저장
			
			if(rs.next()) {
				number=rs.getInt("MAX(j_idx)")+1;	
				//결과값이 있는 경우 rs에서 값을 받아와 +1을 한 뒤 그 번호를 number(글번호)에 저장한다.
			} else {
				number = 1;
			}
			//없으면 글번호 1부터 시작함
			
			
			//현재 인원 최소 1로 먼저 보이게 끔 아예 변수를 줌(sql에서 DEFAULT 1 이 먹지 않아서 임시로 이렇게 해놨어용 )
			nowmem =1;
			
			
			
			
			//21개의 칼럼
			System.out.println("@@@### re ===> "+number);
			System.out.println("@@@### getJ_id() ===> "+join.getJ_id());
			System.out.println("@@@### getJ_nickname ===> "+join.getJ_nickname());
			System.out.println("@@@### getJ_city ===> "+join.getJ_city());
			System.out.println("@@@### getJ_location ===> "+join.getJ_location());
			
			System.out.println("@@@### getJ_hobbyB ===> "+join.getJ_hobbyB());  
			System.out.println("@@@### getJ_hobbyS ===> "+join.getJ_hobbyS());
			System.out.println("@@@### getJ_title ===> "+join.getJ_title());
			System.out.println("@@@### getJ_date ===> "+join.getJ_date());
			System.out.println("@@@### getJ_Dday_Y ===> "+join.getJ_Dday_Y());//
			
			System.out.println("@@@### getJ_Dday_M(===> "+join.getJ_Dday_M());//
			System.out.println("@@@### getJ_Dday_D ===> "+join.getJ_Dday_D());//
			System.out.println("@@@### getJ_Mday_Y ===> "+join.getJ_Mday_Y()); 
			System.out.println("@@@### getJ_Mday_M ===> "+join.getJ_Mday_M()); 
			System.out.println("@@@### getJ_Mday_D ===> "+join.getJ_Mday_D()); 
			
			System.out.println("@@@### getJ_count ===> "+join.getJ_count());
			System.out.println("@@@### getJ_cost ===> "+join.getJ_cost());
			System.out.println("@@@### getJ_maxmem ===> "+join.getJ_maxmem());
			System.out.println("@@@### now_mem ===> "+nowmem); //
			System.out.println("@@@### getJ_content ===> "+join.getJ_content());
			
			System.out.println("@@@### getJ_pwd ===> "+join.getJ_pwd());
			
//												   1  2  3  4  5  6  7  8  9 10 11 12 13 14 15 16 17 18 19 20 21 
			sql="INSERT INTO SEMI_JOINTABLE VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ,?, ?, ?, ?, ?, ?, ?, ?, ?)";
			
			//22개의 칼럼
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, number); 		//글번호 number에 저장된 값 가지고 옴	
			pstmt.setString(2, join.getJ_id()); 
			pstmt.setString(3, join.getJ_nickname());
			pstmt.setString(4, join.getJ_city()); 
			pstmt.setString(5, join.getJ_location()); 
			pstmt.setString(6, join.getJ_hobbyB()); 
			pstmt.setString(7, join.getJ_hobbyS()); 
			pstmt.setString(8, join.getJ_title()); 
			pstmt.setTimestamp(9, join.getJ_date()); 
			pstmt.setString(10, join.getJ_Dday_Y()); 
			pstmt.setString(11, join.getJ_Dday_M()); 
			pstmt.setString(12, join.getJ_Dday_D()); 
			pstmt.setString(13, join.getJ_Mday_Y()); 
			pstmt.setString(14, join.getJ_Mday_M()); 
			pstmt.setString(15, join.getJ_Mday_D()); 
			pstmt.setInt(16, join.getJ_count()); 
			pstmt.setString(17, join.getJ_cost()); 
			pstmt.setInt(18, join.getJ_maxmem()); 
			pstmt.setInt(19, nowmem); //sql에서 default 값 안먹어서 억지로 일단 1을 주었습니다. 아마 신청하기 코드 작성할때 수정 필요할것 같아요ㅠ
			pstmt.setString(20, join.getJ_content()); 
			pstmt.setString(21, join.getJ_pwd()); 
			pstmt.executeUpdate();
			
			re = 1;
			
			
		}catch(SQLException ex) {
			System.out.println("추가 실패");
			ex.printStackTrace();
		}		
		finally {
			try{
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(Exception e){
				e.printStackTrace();
			}
		} 
		return re;
	}
	
	
//	리턴타입이 ArrayList 제네릭 파라미터 리턴값은  JoinBean인 listBoard 메소드
//	글번호와 글 내용을 리턴하여 나타냄
	public ArrayList<JoinBean> listBoard(String pageNumber) throws Exception{
		ArrayList<JoinBean> list = new ArrayList<JoinBean>();

		
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		ResultSet pageSet = null;
		
		
		int dbCount = 0;
		int absolutePage = 1;
		
		String sql= "SELECT j_idx\r\n" + //글번호
					"     , j_id\r\n" +  //아이디
					"     , j_nickname\r\n" + 
					"     , j_city\r\n" + //장소 대분류
					"     , j_location\r\n" +  	//5
					"     , j_hobbyB\r\n" + //취미 대분류
					"     , j_hobbyS\r\n" + 
					"     , j_title\r\n" + 
					"     , j_date\r\n" + 
					"     , j_Dday_Y\r\n" + //마감일자  //10
					"     , j_Dday_M\r\n" + 
					"     , j_Dday_D\r\n" + 
					"     , j_Mday_Y\r\n" + //만나는 날
					"     , j_Mday_M\r\n" + 
					"     , j_Mday_D\r\n" + //15
					"     , j_count\r\n" + //조회수
					"     , j_cost\r\n" + 
					"     , j_maxmem\r\n" + //최대인원
					"     , j_nowmem\r\n" + //현재인원
					"     , j_content\r\n" + //20
					"     , j_pwd\r\n" + 
					"  FROM SEMI_JOINTABLE\r\n" + 
					" ORDER BY j_idx desc";
		
		String sql2= "SELECT COUNT(j_idx) FROM SEMI_JOINTABLE";
		
		try {
			conn = getConnection();
			stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
//			//커서를 특정 위치로 이동시키기 위해 사용
			pageSet = stmt.executeQuery(sql2);
			
			
			
			// pageCount 값을 정함
		
			if (pageSet.next()) {
				dbCount = pageSet.getInt(1);
				pageSet.close();
			}
			if (dbCount % BoardBean.pageSize == 0) {
				BoardBean.pageCount = dbCount / BoardBean.pageSize;
			} else {
				BoardBean.pageCount = dbCount / BoardBean.pageSize + 1;
			}
			if (pageNumber != null) {
				BoardBean.pageNum = Integer.parseInt(pageNumber);
				absolutePage = (BoardBean.pageNum - 1) * BoardBean.pageSize + 1;
			}
			
			
			rs = stmt.executeQuery(sql);
			
			
			
			if (rs.next()) {
				rs.absolute(absolutePage);
				
				int count = 0;
					
				
				while(count < JoinBean.pageSize) {
					//ArrayList에 담아야 해서 joinbean객체 생성
					//join 생성하여
					JoinBean join = new JoinBean();

					//결과값 세팅(다 세팅해놓아야지 나중에 뽑아쓸때 편함)
					join.setJ_idx(rs.getInt(1));
					join.setJ_id(rs.getString(2));
					join.setJ_nickname(rs.getString(3));
					join.setJ_city(rs.getString(4));
					join.setJ_location (rs.getString(5));
					join.setJ_hobbyB (rs.getString(6));
					join.setJ_hobbyS(rs.getString(7));
					join.setJ_title(rs.getString(8));
					join.setJ_date(rs.getTimestamp(9));
					join.setJ_Dday_Y (rs.getString(10));//마감일자
					join.setJ_Dday_M (rs.getString(11));
					join.setJ_Dday_D (rs.getString(12));
					join.setJ_Mday_Y(rs.getString(13));//만나는 날
					join.setJ_Mday_M(rs.getString(14));
					join.setJ_Mday_D(rs.getString(15));
					join.setJ_count(rs.getInt(16));
					join.setJ_cost(rs.getString(17));
					join.setJ_maxmem (rs.getInt(18));
					join.setJ_nowmem(rs.getInt(19));
					join.setJ_content(rs.getString(20));
					join.setJ_pwd(rs.getString(21));
					
					//arraylist에 저장
					list.add(join);
					
					if (rs.isLast()) {
						break;
					} else {
						rs.next();
					}
					
					count++;
//					count가 증가 되어야 10(pageSize)번을 반복함
				}
			}
		}catch(SQLException ex) {
			System.out.println("리스트 실패");
			ex.printStackTrace();
		}		
		finally {
			try{
				if(stmt != null) stmt.close();
				if(conn != null) conn.close();
			}catch(Exception e){
				e.printStackTrace();
			}
		} 
		return list;
	}
	
	// 리턴타입이 JoinBean인 getJoin 메소드
	//글번호만 넘기면 알아서 내용이 넘어가는 메소드(즉 글 보기를 위해서 사용하는 메소드)
	//조회 수 때문에 분기처리  필요
		public JoinBean getJoin(int j_idx, Boolean hit) throws Exception{
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			JoinBean join = new JoinBean();
			String sql = "";

			
			try {
				conn = getConnection();
				
				//참일때 조회수 증가(글을 볼때마 조회수 상승. 
				//수정하거나 작성할때 조회수 추가 하지 못하도록 boolean 사용
				if(hit == true) {
				sql = "UPDATE SEMI_JOINTABLE SET j_count = j_count+1 WHERE j_idx = ?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, j_idx); 
				pstmt.executeUpdate();
				pstmt.close();
				
				sql ="		SELECT j_idx\r\n" + 
						"     , j_id\r\n" + 
						"     , j_nickname\r\n" + 
						"     , j_city\r\n" + 
						"     , j_location\r\n" + //5
						"     , j_hobbyB\r\n" + 
						"     , j_hobbyS\r\n" + 
						"     , j_title\r\n" + 
						"     , j_date\r\n" + 
						"     , j_Dday_Y\r\n" + //10
						"     , j_Dday_M\r\n" + 
						"     , j_Dday_D\r\n" + 
						"     , j_Mday_Y\r\n" + 
						"     , j_Mday_M\r\n" + 
						"     , j_Mday_D\r\n" + //15
						"     , j_count\r\n" + 
						"     , j_cost\r\n" + 
						"     , j_maxmem\r\n" + 
						"     , j_nowmem\r\n" + 
						"     , j_content\r\n" + //20
						"     , j_pwd\r\n" + 
						"  FROM SEMI_JOINTABLE\r\n" +
						" WHERE j_idx = ?";
				
				 
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, j_idx); 
				rs = pstmt.executeQuery();
				} else {
					sql ="		SELECT j_idx\r\n" + 
							"     , j_id\r\n" + 
							"     , j_nickname\r\n" + 
							"     , j_city\r\n" + 
							"     , j_location\r\n" + 
							"     , j_hobbyB\r\n" + 
							"     , j_hobbyS\r\n" + 
							"     , j_title\r\n" + 
							"     , j_date\r\n" + 
							"     , j_Dday_Y\r\n" + 
							"     , j_Dday_M\r\n" + 
							"     , j_Dday_D\r\n" + 
							"     , j_Mday_Y\r\n" + 
							"     , j_Mday_M\r\n" + 
							"     , j_Mday_D\r\n" +  
							"     , j_count\r\n" + 
							"     , j_cost\r\n" + 
							"     , j_maxmem\r\n" + 
							"     , j_nowmem\r\n" + 
							"     , j_content\r\n" + 
							"     , j_pwd\r\n" + 
							"  FROM SEMI_JOINTABLE\r\n" +
							" WHERE j_idx = ?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, j_idx); 
				rs = pstmt.executeQuery();	
				}
								
			if(rs.next()) {
				join.setJ_idx(rs.getInt("j_idx"));
				join.setJ_id(rs.getString("j_id"));
				join.setJ_nickname(rs.getString("j_nickname"));
				join.setJ_city(rs.getString("j_city"));
				join.setJ_location (rs.getString("j_location"));  //5
				join.setJ_hobbyB (rs.getString("j_hobbyB"));
				join.setJ_hobbyS(rs.getString("j_hobbyS"));
				join.setJ_title(rs.getString("j_title"));
				join.setJ_date(rs.getTimestamp("j_date"));
				join.setJ_Dday_Y (rs.getString("j_Dday_Y")); //10
				join.setJ_Dday_M (rs.getString("j_Dday_M"));
				join.setJ_Dday_D (rs.getString("j_Dday_D"));
				join.setJ_Mday_Y(rs.getString("j_Mday_Y"));
				join.setJ_Mday_M(rs.getString("j_Mday_M"));
				join.setJ_Mday_D(rs.getString("j_Mday_D"));//15
				join.setJ_count(rs.getInt("j_count"));
				join.setJ_cost(rs.getString("j_cost"));
				join.setJ_maxmem (rs.getInt("j_maxmem"));
				join.setJ_nowmem(rs.getInt("j_nowmem"));
				join.setJ_content(rs.getString("j_content"));//20
				join.setJ_pwd(rs.getString("j_pwd"));
				}
			
			}catch(SQLException ex) {
				System.out.println("내용 불러오기 실패!");
				ex.printStackTrace();
			}		
			finally {
				try{
					if(pstmt != null) pstmt.close();
					if(conn != null) conn.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			} 
			return join;
		}
		
		
//		deleteJoin
		// BoardDBBean.java에서는
		//public int deleteJoin(int idx, String pwd) throws Exception {로 작성해주셨는데 일단 혹시 모르니깐  그대로 사용할게용
		
		//게시글 삭제 메소드 deleteJoin() 메소드 => 삭제할 글 비밀번호 확인하는 메소드 
		public int deleteJoin(int idx, String pwd) throws Exception {
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			int result = -1;
			
			try {
				conn = getConnection();
				String sql="SELECT j_pwd FROM SEMI_JOINTABLE WHERE j_idx = ?";
				//글 번호에 따른 비밀번호를 출력하는 쿼리문
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, idx); //값을 집어 넣음(위의 쿼리의 ?에 들어감)
				rs = pstmt.executeQuery();
				
				if(rs.next()) {
					if(rs.getString("j_pwd").equals(pwd)) {
						sql="DELETE FROM SEMI_JOINTABLE WHERE j_idx = ?";
						pstmt = conn.prepareStatement(sql);
						pstmt.setInt(1, idx);
						pstmt.executeUpdate();	
						
						result = 1;
					} else {
						result = 2;
					}
				}				
				
			}catch(SQLException ex) {
				System.out.println("삭제 실패");
				ex.printStackTrace();
			}		
			finally {
				try{
					if(pstmt != null) pstmt.close();
					if(conn != null) conn.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			} 
			return result;			
		}
		
//		editJoin() 메소드(게시글 수정 메소드)
		public int editJoin(JoinBean join) throws Exception {

			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			int result = -1;
			
			try {
				conn = getConnection();
				String sql="SELECT j_pwd FROM SEMI_JOINTABLE WHERE j_idx = ?";
				// 글 번호에 따른 비밀번호 가지고 오기
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, join.getJ_idx()); 
				//값을 집어넣음(쿼리의 ?부분),join 객체를 이용하여 j_idx 가지고 오기
				rs = pstmt.executeQuery();
				
				if(rs.next()) {
					if(rs.getString("j_pwd").equals(join.getJ_pwd())) {
						//업데이트 쿼리문 및 if 문에 따라서 j_recruit을 넣어야 하는지 넣지 말아야하는지 몰라서.ㅠ 일단 넣어놓을게요ㅠ -- 김나영
						// 잠시 스탑 9.22 먼저 글 삽입부터 시도 해봐야함(민지언니가 내역 가지고 와야해서)
						
						sql="UPDATE SEMI_JOINTABLE SET  j_id=?\r\n" + 
									"                 , j_nickname=?\r\n" + 
									"                 , j_city=?\r\n" + 
									"                 , j_location=?\r\n" + 
									"                 , j_hobbyB=?\r\n" + 
									"                 , j_hobbyS=?\r\n" + 
									"                 , j_title=?\r\n" + 
									"   			  , j_Dday_Y\r\n" + 
									"     			  , j_Dday_M\r\n" + 
									"      			  , j_Dday_D\r\n" +   //10
									"      			  , j_Mday_Y\r\n" + 
									"   			  , j_Mday_M\r\n" + 
									"   			  , j_Mday_D\r\n" +  
									"                 , j_cost=?\r\n" + 
									"                 , j_maxmem=?\r\n" + 
									"                 , j_content=?\r\n" + 
									"             WHERE j_idx = ?";
						pstmt = conn.prepareStatement(sql);
						pstmt.setString(1, join.getJ_id());
						pstmt.setString(2, join.getJ_nickname());
						pstmt.setString(3, join.getJ_city());
						pstmt.setString(4, join.getJ_location());
						pstmt.setString(5, join.getJ_hobbyB());
						pstmt.setString(6, join.getJ_hobbyS());
						pstmt.setString(7, join.getJ_title());
						pstmt.setString(8, join.getJ_Dday_Y());
						pstmt.setString(9, join.getJ_Dday_M());
						pstmt.setString(10, join.getJ_Dday_D());
						pstmt.setString(11, join.getJ_Mday_Y());
						pstmt.setString(12, join.getJ_Mday_M());
						pstmt.setString(13, join.getJ_Mday_D());
						pstmt.setString(14, join.getJ_cost());
						pstmt.setInt(15, join.getJ_maxmem());
						pstmt.setString(16, join.getJ_content());
						pstmt.setInt(17, join.getJ_idx());
						pstmt.executeUpdate();	
//						
						result = 1;
					} else {
						result = 2;
					}
				}				
				
			}catch(SQLException ex) {
				System.out.println("수정 실패");
				ex.printStackTrace();
			}		
			finally {
				try{
					if(pstmt != null) pstmt.close();
					if(conn != null) conn.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			} 
			return result;				
		}	
	
}
