package hobbyPlanet.member;

import java.sql.Timestamp;

public class HobbyMemberBean {
	private String h_uid;
	private String h_pwd;
	private String h_name;
	private String h_email;
	private Timestamp h_regdate;
	public String getH_uid() {
		return h_uid;
	}
	public void setH_uid(String h_uid) {
		this.h_uid = h_uid;
	}
	public String getH_pwd() {
		return h_pwd;
	}
	public void setH_pwd(String h_pwd) {
		this.h_pwd = h_pwd;
	}
	public String getH_name() {
		return h_name;
	}
	public void setH_name(String h_name) {
		this.h_name = h_name;
	}
	public String getH_email() {
		return h_email;
	}
	public void setH_email(String h_email) {
		this.h_email = h_email;
	}
	public Timestamp getH_regdate() {
		return h_regdate;
	}
	public void setH_regdate(Timestamp h_regdate) {
		this.h_regdate = h_regdate;
	}
	public String getH_addr() {
		return h_addr;
	}
	public void setH_addr(String h_addr) {
		this.h_addr = h_addr;
	}
	private String h_addr;
	
}
