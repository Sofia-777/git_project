
function check_ok() {
	//if(document.reg_frm.mem_uid.value == ""){
	/*if(reg_frm.mem_uid.value == ""){*/
	// document를 생략해도 경로를 찾을 수 있다.form과 input의 name을 잘 주어주기.
	if(reg_frm.h_uid.value.length == 0){	
		alert("아이디를 입력하세요.");
		reg_frm.h_uid.focus();
		return;
	} 
	
	if(reg_frm.h_uid.value.length < 4){
		alert("아이디는 4글자 이상 입력하여야 합니다.");
		reg_frm.h_uid.focus();
		return;
	} 
	
	if(reg_frm.h_pwd.value == ""){
		alert("패스워드는 반드시 입력해야 합니다.");
		reg_frm.h_pwd.focus();
		return;
	} 
	
	if(reg_frm.h_pwd.value != document.reg_frm.h_pwd_ck.value){
		alert("패스워드가 일치하지 않습니다.");
		reg_frm.h_pwd_ck.focus();
		return;
	} 
	
	if(reg_frm.h_name.value == ""){
		alert("이름을 써주세요.");
		reg_frm.h_name.focus();
		return;
	} 
	
	if(reg_frm.h_email.value == ""){
		alert("Email을 써주세요.");
		reg_frm.h_email.focus();
		return;
	} 
	document.reg_frm.submit();
	// if문에 충족하지 않으면 form에 있는 action으로 submit 하겠다.
}

function update_check_ok() {
	if(update_frm.h_pwd.value.length == 0){	
		alert("패스워드는 반드시 입력해야 합니다.");
		update_frm.h_pwd.focus();
		return;
	} 
	
	if(update_frm.h_pwd.value != update_frm.h_pwd_ck.value){
		alert("패스워드가 일치하지 않습니다.");
		update_frm.h_pwd_ck.focus();
		return;
	}
	
	if(update_frm.h_email.value == ""){
		alert("Email을 써주세요.");
		update_frm.h_email.focus();
		return;
	}
	document.update_frm.submit();
	// if문에 충족하지 않으면 form에 있는 action으로 submit 하겠다.
}