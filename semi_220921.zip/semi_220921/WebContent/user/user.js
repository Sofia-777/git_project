function register_ok() {
	if(register_form.u_id.value.length == 0) {
		alert("아이디를 써주세요.");
		register_form.u_id.focus();
		return;
	}

	if(register_form.u_id.value.length < 6) {
		alert("아이디는 6글자 이상이어야 합니다.");
		register_form.u_id.focus();
		return;
	}
	
	if(register_form.u_pwd.value.length == 0) {
		alert("비밀번호를 써주세요.");
		register_form.u_pwd.focus();
		return;
	}
	
	if(register_form.u_pwd.value.length < 6) {
		alert("비밀번호는 6글자 이상이어야 합니다.");
		register_form.u_pwd.focus();
		return;
	}
	
	if(register_form.u_pwd_check.value != register_form.u_pwd.value) {
		alert("비밀번호가 일치하지 않습니다.");
		register_form.u_pwd_check.focus();
		return;
	}
	
	if(register_form.u_nickname.value.length == 0) {
		alert("닉네임을 써주세요.");
		register_form.u_nickname.focus();
		return;
	}
	
	if(register_form.u_nickname.value.length < 4) {
		alert("닉네임은 4글자 이상이어야 합니다.");
		register_form.u_nickname.focus();
		return;
	}
	
	if(register_form.u_name.value.length == 0) {
		alert("이름을 써주세요.");
		register_form.u_name.focus();
		return;
	}
	
	if(register_form.u_email.value.length == 0) {
		alert("Email을 써주세요.");
		register_form.u_email.focus();
		return;
	}
	
	if(register_form.u_tel.value.length == 0) {
		alert("전화번호를 써주세요.");
		register_form.u_tel.focus();
		return;
	}
	
	if(register_form.u_addr.value.length == 0) {
		alert("주소를 써주세요.");
		register_form.u_addr.focus();
		return;
	}
	
	if(register_form.u_gender.value.length == 0) {
		alert("성별을 선택해주세요.");
		register_form.u_gender.focus();
		return;
	}
	
	document.register_form.submit();
}

function update_ok() {
	if(update_form.u_pwd.value.length == 0) {
		alert("비밀번호를 써주세요.");
		update_form.u_pwd.focus();
		return;
	}
	
	if(update_form.u_pwd.value.length < 6) {
		alert("비밀번호는 6글자 이상이어야 합니다.");
		update_form.u_pwd.focus();
		return;
	}
	
	if(update_form.u_pwd_check.value != update_form.u_pwd.value) {
		alert("비밀번호가 일치하지 않습니다.");
		update_form.u_pwd_check.focus();
		return;
	}
	
	if(update_form.u_nickname.value.length == 0) {
		alert("닉네임을 써주세요.");
		update_form.u_nickname.focus();
		return;
	}
	
	if(update_form.u_nickname.value.length < 4) {
		alert("닉네임은 4글자 이상이어야 합니다.");
		update_form.u_nickname.focus();
		return;
	}
	
	if(update_form.u_name.value.length == 0) {
		alert("이름을 써주세요.");
		update_form.u_name.focus();
		return;
	}
	
	if(update_form.u_email.value.length == 0) {
		alert("Email을 써주세요.");
		update_form.u_email.focus();
		return;
	}
	
	if(update_form.u_tel.value.length == 0) {
		alert("전화번호를 써주세요.");
		update_form.u_tel.focus();
		return;
	}
	
	if(update_form.u_addr.value.length == 0) {
		alert("주소를 써주세요.");
		update_form.u_addr.focus();
		return;
	}
	
	if(update_form.u_gender.value.length == 0) {
		alert("성별을 선택해주세요.");
		update_form.u_gender.focus();
		return;
	}
	
	document.update_form.submit();
}

function delete_ok() {
	if(delete_form.u_pwd.value.length == 0) {
		alert("비밀번호를 입력해주세요.");
		delete_form.u_pwd.focus();
		return;
	}
	
	document.delete_form.submit();
}