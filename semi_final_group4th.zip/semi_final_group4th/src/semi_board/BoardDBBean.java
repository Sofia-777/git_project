package semi_board;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;


public class BoardDBBean {
//	전역 BoardDBBean 객체 레퍼런스를 리턴하는 메소드
	private static BoardDBBean instance = new BoardDBBean();
	
	public static BoardDBBean getInstance() {
		return instance;
	}
	
//	쿼리작업에 사용할 커넥션 객체를 리턴하는 메소드
	public Connection getConnection() throws Exception {
		Context ctx = new InitialContext();
		DataSource ds = (DataSource)ctx.lookup("java:comp/env/jdbc/oracle");
		return ds.getConnection();
	}
	
//	전달인자로 받은 board를 SEMI_BOARDTABLE 테이블에 삽입하는 메소드
	public int insertBoard(BoardBean board) throws Exception{
		int re = -1;
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql="SELECT MAX(b_idx) FROM SEMI_BOARDTABLE";
//		글번호 순서를 위한 쿼리로 글번호 중 제일 큰 값을 찾는다.
		int number=1;
//		1의 값을 갖고있어야 결과값이 없을 때(테이블에 데이터가 없을 시) 번호 1이 부여된다.
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
//			최대값을 찾은 결과를 rs에 저장한다.
			if(rs.next()) {
				number=rs.getInt("MAX(b_idx)")+1;
//				결과값이 있는 경우 rs에서 해당값을 받아와 +1을 한 뒤 그 번호를 number에 저장한다.
			} else {
				number = 1;
			}
			
			sql="INSERT INTO SEMI_BOARDTABLE VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, number); 
			pstmt.setString(2, board.getB_id()); 
			pstmt.setString(3, board.getB_nickname());
			pstmt.setString(4, board.getB_title()); 
			pstmt.setString(5, board.getB_content()); 
			pstmt.setTimestamp(6, board.getB_date()); 
			pstmt.setInt(7, board.getB_count()); 
			pstmt.setString(8, board.getB_pwd()); 
			pstmt.setInt(9, board.getB_admindel()); 
			pstmt.executeUpdate();
			
			re = 1;
		}catch(SQLException ex) {
			System.out.println("저장 실패");
			ex.printStackTrace();
		}		
		finally {
			try{
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(Exception e){
				e.printStackTrace();
			}
		} 
		return re;
	}
	
//	리턴타입이 ArrayList 제네릭 파라미터 리턴값은 BoardBean인 listBoard 메소드
	public ArrayList<BoardBean> listBoard(String pageNumber) throws Exception{
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		ResultSet pageSet = null;
		int dbCount = 0;
//		총 글의 개수에 대한 값을 담는 변수 생성
		int absolutePage = 1;
		
		String sql= "SELECT b_idx\r\n" + 
					"     , b_id\r\n" + 
					"     , b_nickname\r\n" + 
					"     , b_title\r\n" + 
					"     , b_content\r\n" + 
					"     , b_date\r\n" + 
					"     , b_count\r\n" + 
					"     , b_pwd\r\n" + 
					"     , b_admindel\r\n" + 
					"  FROM SEMI_BOARDTABLE\r\n" + 
					" ORDER BY b_idx desc";
		
		String sql2= "SELECT COUNT(b_idx) FROM SEMI_BOARDTABLE";
		ArrayList<BoardBean> list = new ArrayList<BoardBean>();
		
		try {
			conn = getConnection();
			stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
//			커서를 특정 위치로 이동시키기 위함.
			pageSet = stmt.executeQuery(sql2);
			
			if (pageSet.next()) {
				dbCount = pageSet.getInt(1);
				pageSet.close();
			}
			
//				pageCount 값을 정하는 식, BoardBean에선 임의로 1개 지정되어 있음.
//				게시글의 개수는 늘 변동이 되므로 pageCount 값이 달라질 수 있다.
			if (dbCount % BoardBean.pageSize == 0) {
//				예) 84 / 10 의 나머지가 4, 0이 아닐 경우
				BoardBean.pageCount = dbCount / BoardBean.pageSize;
				
			} else {
				BoardBean.pageCount = dbCount / BoardBean.pageSize + 1;
//				84 / 10 + 1 = 9 이므로 pageCount는 9가 된다
			}
			
//			만약 작업 도중 그 작업을 그만 둘 때 다시 돌아가려면 이전의 pageNumber가 필요하므로
			if (pageNumber != null) {
				BoardBean.pageNum = Integer.parseInt(pageNumber);
				absolutePage = (BoardBean.pageNum - 1) * BoardBean.pageSize + 1;
//				예를 들어 1페이지엔 1~10글이, 2페이지엔 11~20이 묶음이 되므로
			}
			rs = stmt.executeQuery(sql);
			
			if (rs.next()) {
				rs.absolute(absolutePage);
//				커서를 특정 위치로 이동시키기 위한 메소드
				int count = 0;
					while(count < BoardBean.pageSize) {
					BoardBean board = new BoardBean();
					
					board.setB_idx(rs.getInt(1));
					board.setB_id(rs.getString(2));
					board.setB_nickname(rs.getString(3));
					board.setB_title(rs.getString(4));
					board.setB_content(rs.getString(5));
					board.setB_date(rs.getTimestamp(6));
					board.setB_count(rs.getInt(7));
					board.setB_pwd(rs.getString(8));
					board.setB_admindel(rs.getInt(9));
					
					list.add(board);
					
					if (rs.isLast()) {
						break;
//						예를 들어 84개의 게시글 중 84번째의 게시글 정보가 오면
//						더이상 반복할 이유가 없기 때문
					} else {
						rs.next();
					}
					
					count++;
//					count가 증가 되어야 10(pageSize)번을 반복함
				}
			}
		}catch(SQLException ex) {
			System.out.println("불러오기 실패");
			ex.printStackTrace();
		}		
		finally {
			try{
				if(rs != null) rs.close();
				if(stmt != null) stmt.close();
				if(conn != null) conn.close();
			}catch(Exception e){
				e.printStackTrace();
			}
		} 
		return list;
	}
	
//	리턴타입이 BoardBean인 getBoard(), 
//	매개변수 글번호를 통해 작성자~글내용까지 BoardBean에 담아서 리턴
		public BoardBean getBoard(int b_idx, Boolean hit) throws Exception{
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			BoardBean board = new BoardBean();
			String sql = "";

			
			try {
				conn = getConnection();
				if(hit == true) {
				sql = "UPDATE SEMI_BOARDTABLE SET b_count = b_count+1 WHERE b_idx = ?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, b_idx); 
				pstmt.executeUpdate();
				pstmt.close();
				
				sql ="	 SELECT b_idx\r\n" + 
						"     , b_id\r\n" + 
						"     , b_nickname\r\n" + 
						"     , b_title\r\n" + 
						"     , b_content\r\n" + 
						"     , b_date\r\n" + 
						"     , b_count\r\n" + 
						"     , b_pwd\r\n" + 
						"     , b_admindel\r\n" + 
						"  FROM SEMI_BOARDTABLE\r\n" + 
						" WHERE b_idx = ?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, b_idx); 
				rs = pstmt.executeQuery();
				} else {
				sql ="	 SELECT b_idx\r\n" + 
						"     , b_id\r\n" + 
						"     , b_nickname\r\n" + 
						"     , b_title\r\n" + 
						"     , b_content\r\n" + 
						"     , b_date\r\n" + 
						"     , b_count\r\n" + 
						"     , b_pwd\r\n" + 
						"     , b_admindel\r\n" + 
						"  FROM SEMI_BOARDTABLE\r\n" + 
						" WHERE b_idx = ?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, b_idx); 
				rs = pstmt.executeQuery();					
				}
								
			if(rs.next()) {
				board.setB_idx(rs.getInt("b_idx"));
				board.setB_id(rs.getString("b_id"));
				board.setB_nickname(rs.getString("b_nickname"));
				board.setB_title(rs.getString("b_title"));
				board.setB_content(rs.getString("b_content"));
				board.setB_date(rs.getTimestamp("b_date"));
				board.setB_count(rs.getInt("b_count"));
				board.setB_pwd(rs.getString("b_pwd"));
				board.setB_admindel(rs.getInt("b_admindel"));
				}
			
			}catch(SQLException ex) {
				System.out.println("불러오기 실패");
				ex.printStackTrace();
			}		
			finally {
				try{
					if(rs != null) rs.close();
					if(pstmt != null) pstmt.close();
					if(conn != null) conn.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			} 
			return board;
		}
		
		
//		게시글 삭제 메소드 - 게시글 삭제 시 하위 댓글도 삭제되어야 한다.
		public int deleteBoard(int idx, String pwd) throws Exception {
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			int result = -1;
			
			
			try {
				conn = getConnection();
				
//				게시글 고유 번호에 따른 댓글이 있는 지 확인한다.
				String sqlComment="SELECT * FROM SEMI_BOARDCOMMENT WHERE BC_BIDX = ?";
				pstmt = conn.prepareStatement(sqlComment);
				pstmt.setInt(1, idx); 
				rs = pstmt.executeQuery();
				
//				해당 게시글에 댓글이 있을 시 공유 받는 게시글 고유 번호에 해당하는 댓글은 모두 삭제한다.
				if(rs.next()) {
					String sqlCommentDel="DELETE FROM SEMI_BOARDCOMMENT WHERE bc_bidx = ?";
					pstmt = conn.prepareStatement(sqlCommentDel);
					pstmt.setInt(1, idx);
					pstmt.executeUpdate();
				}
				pstmt.close();
				rs.close();
				
				String sql="SELECT b_pwd FROM SEMI_BOARDTABLE WHERE b_idx = ?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, idx); 
				rs = pstmt.executeQuery();
				
				if(rs.next()) {
					if(rs.getString("b_pwd").equals(pwd)) {
						sql="DELETE FROM SEMI_BOARDTABLE WHERE b_idx = ?";
						pstmt = conn.prepareStatement(sql);
						pstmt.setInt(1, idx);
						pstmt.executeUpdate();	
						
						result = 1;
					} else {
						result = 2;
					}
				}				
				
			}catch(SQLException ex) {
				System.out.println("삭제 실패");
				ex.printStackTrace();
			}		
			finally {
				try{
					if(rs != null) rs.close();
					if(pstmt != null) pstmt.close();
					if(conn != null) conn.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			} 
			return result;			
		}
		
//		게시글 수정 메소드
		public int editBoard(BoardBean board) throws Exception {

			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			int result = -1;
			
			try {
				conn = getConnection();
				String sql="SELECT b_pwd FROM SEMI_BOARDTABLE WHERE b_idx = ?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, board.getB_idx()); 
				rs = pstmt.executeQuery();
				
				if(rs.next()) {
					if(rs.getString("b_pwd").equals(board.getB_pwd())) {
						sql="UPDATE SEMI_BOARDTABLE SET b_id=?\r\n" + 
									"                 , b_nickname=?\r\n" + 
									"                 , b_title=?\r\n" + 
									"                 , b_content=? \r\n" + 
									"                 , b_admindel=? \r\n" + 
									"             WHERE b_idx = ?";
						pstmt = conn.prepareStatement(sql);
						pstmt.setString(1, board.getB_id());
						pstmt.setString(2, board.getB_nickname());
						pstmt.setString(3, board.getB_title());
						pstmt.setString(4, board.getB_content());
						pstmt.setInt(5, board.getB_admindel());
						pstmt.setInt(6, board.getB_idx());
						pstmt.executeUpdate();	
						
						result = 1;
					} else {
						result = 2;
					}
				}				
				
			}catch(SQLException ex) {
				System.out.println("수정 실패");
				ex.printStackTrace();
			}		
			finally {
				try{
					if(rs != null) rs.close();
					if(pstmt != null) pstmt.close();
					if(conn != null) conn.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			} 
			return result;				
		}	
}
