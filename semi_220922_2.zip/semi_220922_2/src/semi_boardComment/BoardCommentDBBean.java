package semi_boardComment;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import semi_board.BoardBean;



public class BoardCommentDBBean {

	private static BoardCommentDBBean instance = new BoardCommentDBBean();
	
//	전역 BoardCommentDBBean 객체 레퍼런스를 리턴하는 메소드
	public static BoardCommentDBBean getInstance() {
		return instance;
	}
	 
//	쿼리작업에 사용할 커넥션 객체를 리턴하는 메소드
	public Connection getConnection() throws Exception {
		Context ctx = new InitialContext();
		DataSource ds = (DataSource)ctx.lookup("java:comp/env/jdbc/oracle");
		return ds.getConnection();
	}
	
//	전달인자로 받은 comment를 SEMI_BOARDCOMMENT 테이블에 삽입하는 메소드
	public int insertComment(BoardCommentBean comment) throws Exception{
		int re = -1;
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql="SELECT MAX(BC_IDX) FROM SEMI_BOARDCOMMENT";
//		글번호 순서를 위한 쿼리로 글번호 중 제일 큰 값을 찾는다.
		int number=1;
//		1로 시작해야 결과값이 없을 때(테이블에 데이터가 없을 시) 번호 1이 부여된다.
		int idx = comment.getBc_idx();
		int ref = comment.getBc_ref();
		int step = comment.getBc_step();
		int level = comment.getBc_level();
//		먼저 대댓글인지 아닌지 구분을 위해 bc_idx를 들고와야 한다.
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
//			최대값을 찾은 결과를 rs에 저장한다.
			if(rs.next()) {
				number=rs.getInt("MAX(BC_IDX)")+1;
//			결과값이 있는 경우 rs에서 해당값을 받아와 +1을 한 뒤 그 번호를 number에 저장한다.
			} else {
				number = 1;
			}
			
			
			if (idx != 0) {
				sql="UPDATE SEMI_BOARDCOMMENT SET BC_STEP=BC_STEP+1 WHERE BC_REF=? AND BC_STEP > ?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, ref);
				pstmt.setInt(2, step);
				pstmt.executeUpdate();
				step = step+1;
				level = level+1;
			} else {
				ref = number;
				step = 0;
				level = 0;
			}

			
				sql="INSERT INTO SEMI_BOARDCOMMENT VALUES(?, ?, ?, ?, ?, sysdate, ?, ?, ?)";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, number);
				pstmt.setInt(2, comment.getBc_bidx());
				pstmt.setString(3, comment.getBc_id());
				pstmt.setString(4, comment.getBc_nickname());
				pstmt.setString(5, comment.getBc_content());
				pstmt.setInt(6, comment.getBc_ref());
				pstmt.setInt(7, comment.getBc_step());
				pstmt.setInt(8, comment.getBc_level());
				pstmt.executeUpdate();

			re = 1;
		}catch(SQLException ex) {
			System.out.println("추가 실패");
			ex.printStackTrace();
		}		
		finally {
			try{
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(Exception e){
				e.printStackTrace();
			}
		} 
		return re;
	}

//	리턴타입이 ArrayList 제네릭 파라미터 리턴값은 BoardCommentBean인 listComment 메소드
//	매개변수에 게시물 인덱스 번호와 댓글의 페이징 번호를 받아 list 출력
	public ArrayList<BoardCommentBean> listComment(int idx, String pageNumber) throws Exception{
		Connection conn = null;
		Statement stmt = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ResultSet pageSet = null;
		int dbCount = 0;
//		총 글의 개수에 대한 값을 담는 변수
		int absolutePage = 1;
//		머물던 페이지로의 파일럿을 위한 변수
		
		String sql="SELECT bc_idx\r\n" + 
				" 	     , bc_bidx\r\n" + 
				" 	     , bc_id\r\n" + 
				"  	     , bc_nickname\r\n" + 
				"  	     , bc_content\r\n" + 
				"  	     , bc_date \r\n" + 
				   "  FROM SEMI_BOARDCOMMENT \r\n" + 
				"    WHERE bc_bidx = ?\r\n" + 
				" ORDER BY bc_date";
		
		String sql2 = "SELECT COUNT(bc_idx) FROM SEMI_BOARDCOMMENT WHERE BC_BIDX = ?";
		ArrayList<BoardCommentBean> commentList = new ArrayList<BoardCommentBean>();
		
		try {
			conn = getConnection();
			stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
			pstmt = conn.prepareStatement(sql2);
			pstmt.setInt(1, idx);
			pageSet = pstmt.executeQuery();
			
			if (pageSet.next()) {
				dbCount = pageSet.getInt(1);
				pageSet.close();
			}
			
//			pageCount 값을 정하는 식, BoardCommentBean에선 임의로 1개 지정되어 있음.
//			게시글의 개수는 늘 변동이 되므로 pageCount 값이 달라질 수 있다.
			if (dbCount % BoardCommentBean.cmPageSize == 0) {
				// 예) 84 / 10 의 나머지가 4, 0이 아닐 경우
				BoardCommentBean.cmPageCount = dbCount / BoardCommentBean.cmPageSize;
				
			} else {
				BoardCommentBean.cmPageCount = dbCount / BoardCommentBean.cmPageSize + 1;
				// 84 / 10 + 1 = 9 이므로 pageCount는 9가 된다.
			}
			
			// 만약 작업 도중 그 작업을 그만 둘 때 다시 돌아가려면 이전의 pageNumber가 필요하므로
			// 아니면 항상 1페이지로 돌아가기 때문에
			if (pageNumber != null) {
				BoardCommentBean.cmPageNum = Integer.parseInt(pageNumber);
				absolutePage = (BoardCommentBean.cmPageNum - 1) * BoardCommentBean.cmPageSize + 1;
				// 예를 들어 1페이지엔 1~10글이, 2페이지엔 11~20이 묶음이 되므로
				// 내가 3페이지를 보고 있었으면 (3-1)*10+1=21의 값이 나오는데
				// 3페이지 첫 시작 글이 21이므로 이런 식의 파일럿이 가능.
			}
			rs = stmt.executeQuery(sql);
			////////////// 오류남 ////////////////////////
			
			if (rs.next()) {
				rs.absolute(absolutePage);
//				커서를 특정 위치로 이동시키기 위한 메소드
				int count = 0;
					while(count < BoardCommentBean.cmPageSize) {
						BoardCommentBean comment = new BoardCommentBean();
					
						comment.setBc_idx(rs.getInt(1));				
						comment.setBc_bidx(rs.getInt(2));				
						comment.setBc_id(rs.getString(3));				
						comment.setBc_nickname(rs.getString(4));				
						comment.setBc_content(rs.getString(5));				
						comment.setBc_date(rs.getTimestamp(6));				
						
						commentList.add(comment);
					
					if (rs.isLast()) {
						break;
					// 예를 들어 84개의 게시글 중 84번째의 게시글 정보가 오면
					// 더이상 반복할 이유가 없기 때문
					} else {
						rs.next();
					}
					
					count++;
					// count가 증가 되어야 10(pageSize)번을 반복함
				}
			}
		}catch(SQLException ex) {
			System.out.println("불러오기 실패");
			ex.printStackTrace();
		}		
		finally {
			try{
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(Exception e){
				e.printStackTrace();
			}
		} 
		return commentList;
	}
	
	// 리턴타입이 BoardCommentBean인 getBoardComment(), 
	// 매개변수 글번호를 통해 작성자~글내용까지 BoardCommentBean에 담아서 리턴
		public BoardCommentBean getBoardComment(int bc_idx) throws Exception{
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			BoardCommentBean comment = new BoardCommentBean();
			String sql = "";

			
			try {
				conn = getConnection();							
				sql ="	 SELECT BC_IDX\r\n" + 
						"     , BC_BIDX\r\n" + 
						"     , BC_ID\r\n" + 
						"     , BC_NICKNAME\r\n" + 
						"     , BC_CONTENT\r\n" + 
						"     , BC_DATE\r\n" + 
						"     , BC_REF\r\n" + 
						"     , BC_STEP\r\n" + 
						"     , BC_LEVEL\r\n" + 
						"  FROM SEMI_BOARDCOMMENT\r\n" + 
						" WHERE BC_IDX = ?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, bc_idx); 
				rs = pstmt.executeQuery();
					
			if(rs.next()) {
				comment.setBc_idx(rs.getInt("bc_idx"));
				comment.setBc_bidx(rs.getInt("bc_bidx"));
				comment.setBc_id(rs.getString("bc_id"));
				comment.setBc_nickname(rs.getString("bc_nickname"));
				comment.setBc_content(rs.getString("bc_content"));
				comment.setBc_date(rs.getTimestamp("bc_date"));
				comment.setBc_ref(rs.getInt("bc_ref"));
				comment.setBc_step(rs.getInt("bc_step"));
				comment.setBc_level(rs.getInt("bc_level"));
				}
			
				
			}catch(SQLException ex) {
				System.out.println("불러오기 실패");
				ex.printStackTrace();
			}		
			finally {
				try{
					if(pstmt != null) pstmt.close();
					if(conn != null) conn.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			} 
			return comment;
		}

		
//		댓글 삭제 메소드
		public int deleteComment(int idx) throws Exception {
			Connection conn = null;
			PreparedStatement pstmt = null;
			int result = -1;
			
			try {
				conn = getConnection();
				String sql="DELETE FROM SEMI_BOARDCOMMENT WHERE bc_idx = ?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, idx); 
				pstmt.executeUpdate();
				System.out.println(idx);
				
				result = 1;
			}catch(SQLException ex) {
				System.out.println("삭제 실패");
				ex.printStackTrace();
			}		
			finally {
				try{
					if(pstmt != null) pstmt.close();
					if(conn != null) conn.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			} 
			return result;			
		}
				

}
