package semi_join;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import semi_board.BoardBean;
import semi_board.BoardDBBean;
import semi_user.UserBean;
import semi_user.UserDBBean;



public class JoinDBBean {
	// �옉�꽦�옄 : 源��굹�쁺 
	// �궇吏� : 2022.09.22 ~ 09.25
	//�븳湲� 源⑥쭊 �쁽�긽 諛쒖깮
	//�뙣�뱾�젢�쓽 �뼵�땲�뱾�쓽 �젙由щ낯 蹂대㈃�꽌 �옉�꽦�뻽�뼱�슂!!!
	//( �젣嫄�..... 媛뺤궗�떂 �냼�뒪 �궗�슜�븯怨� �엳援� �븘留� 鍮좎쭊 �꽕紐� 鍮좎쭊 遺�遺꾩씠 留롮븘�꽌..誘우쓣 �닔媛� �뾾�뼱�슂)
	
	
	
	private static JoinDBBean instance = new JoinDBBean();
	//�쟾�뿭 joinBean 媛앹껜 �젅�띁�윴�뒪瑜� 由ы꽩�븯�뒗 硫붿냼�뱶
	public static JoinDBBean getInstance() {
		return instance;
	}
	
//	荑쇰━ �옉�뾽�뿉 �궗�슜�븷 而ㅻ꽖�뀡 媛앹껜瑜� 由ы꽩�븯�뒗 硫붿냼�뱶
	public Connection getConnection() throws Exception {
		Context ctx = new InitialContext();
		DataSource ds = (DataSource)ctx.lookup("java:comp/env/jdbc/oracle");
		return ds.getConnection();
	}
	
//	�쟾�떖�씤�옄濡� 諛쏆� join�쓣 SEMI_JOINTABLE�뿉 �궫�엯�븯�뒗 insertJoin 硫붿냼�뱶(湲� �궫�엯)
	public int insertJoin(JoinBean join) throws Exception{
		int re = -1;
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql="SELECT MAX(j_idx) FROM SEMI_JOINTABLE";
		//湲� 踰덊샇 �닚�꽌瑜� �쐞�븳 荑쇰━. 湲� 踰덊샇 以� �젣�씪 �겙 媛믪쓣 李얠쓬
		int number=1;
		// 1濡� �떆�옉�빐�빞吏� �뀒�씠釉붿뿉 �뜲�씠�꽣媛� �뾾�쓣�븣 踰덊샇 1�씠 遺��뿬�맖.
		
		int nowmem=join.getJ_nowmem();
		//�쁽�옱 �씤�썝(理쒖냼 1紐�=�옉�꽦�옄)瑜� �몴湲� �븯湲� �쐞�빐�꽌 join �쟾�떖�씤�옄瑜� 諛쏆븘�꽌 �븯�젮怨� �븯���쓬
		int idx = join.getJ_idx();
		// �쐞�쓽 idx�뒗 �썝�옒 �떟湲� �몴湲고븯湲� �쐞�빐�꽌 �궗�슜�븯�뒗 肄붾뱶 以� �븯�굹�씤�벏�븿
		//�씪�떒 �궘�젣 �떆�룄
		
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			//理쒕�媛믪쓣 李얠� 寃곌낵 rs�뿉 ���옣
			
			if(rs.next()) {
				number=rs.getInt("MAX(j_idx)")+1;	
				//寃곌낵媛믪씠 �엳�뒗 寃쎌슦 rs�뿉�꽌 媛믪쓣 諛쏆븘�� +1�쓣 �븳 �뮘 洹� 踰덊샇瑜� number(湲�踰덊샇)�뿉 ���옣�븳�떎.
			} else {
				number = 1;
			}
			//�뾾�쑝硫� 湲�踰덊샇 1遺��꽣 �떆�옉�븿
			
			
			//�쁽�옱 �씤�썝 理쒖냼 1濡� 癒쇱� 蹂댁씠寃� �걫 �븘�삁 蹂��닔瑜� 以�(sql�뿉�꽌 DEFAULT 1 �씠 癒뱀� �븡�븘�꽌 �엫�떆濡� �씠�젃寃� �빐�넧�뼱�슜 )
			nowmem =1;
			
			
			
			
			//21媛쒖쓽 移쇰읆
//			System.out.println("@@@### re ===> "+number);
//			System.out.println("@@@### getJ_id() ===> "+join.getJ_id());
//			System.out.println("@@@### getJ_nickname ===> "+join.getJ_nickname());
//			System.out.println("@@@### getJ_city ===> "+join.getJ_city());
//			System.out.println("@@@### getJ_location ===> "+join.getJ_location());
//			
//			System.out.println("@@@### getJ_hobbyB ===> "+join.getJ_hobbyB());  
//			System.out.println("@@@### getJ_hobbyS ===> "+join.getJ_hobbyS());
//			System.out.println("@@@### getJ_title ===> "+join.getJ_title());
//			System.out.println("@@@### getJ_date ===> "+join.getJ_date());
//			System.out.println("@@@### getJ_Dday_Y ===> "+join.getJ_Dday_Y());//
//			
//			System.out.println("@@@### getJ_Dday_M(===> "+join.getJ_Dday_M());//
//			System.out.println("@@@### getJ_Dday_D ===> "+join.getJ_Dday_D());//
//			System.out.println("@@@### getJ_Mday_Y ===> "+join.getJ_Mday_Y()); 
//			System.out.println("@@@### getJ_Mday_M ===> "+join.getJ_Mday_M()); 
//			System.out.println("@@@### getJ_Mday_D ===> "+join.getJ_Mday_D()); 
//			
//			System.out.println("@@@### getJ_count ===> "+join.getJ_count());
//			System.out.println("@@@### getJ_cost ===> "+join.getJ_cost());
//			System.out.println("@@@### getJ_maxmem ===> "+join.getJ_maxmem());
//			System.out.println("@@@### now_mem ===> "+nowmem); //
//			System.out.println("@@@### getJ_content ===> "+join.getJ_content());
//			
//			System.out.println("@@@### getJ_pwd ===> "+join.getJ_pwd());
			
//												   1  2  3  4  5  6  7  8  9 10 11 12 13 14 15 16 17 18 19 20 21 
			sql="INSERT INTO SEMI_JOINTABLE VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ,?, ?, ?, ?, ?, ?, ?, ?, ?)";
			
			//22媛쒖쓽 移쇰읆
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, number); 		//湲�踰덊샇 number�뿉 ���옣�맂 媛� 媛�吏�怨� �샂	
			pstmt.setString(2, join.getJ_id()); 
			pstmt.setString(3, join.getJ_nickname());
			pstmt.setString(4, join.getJ_city()); 
			pstmt.setString(5, join.getJ_location()); 
			pstmt.setString(6, join.getJ_hobbyB()); 
			pstmt.setString(7, join.getJ_hobbyS()); 
			pstmt.setString(8, join.getJ_title()); 
			pstmt.setTimestamp(9, join.getJ_date()); 
			pstmt.setString(10, join.getJ_Dday_Y()); 
			pstmt.setString(11, join.getJ_Dday_M()); 
			pstmt.setString(12, join.getJ_Dday_D()); 
			pstmt.setString(13, join.getJ_Mday_Y()); 
			pstmt.setString(14, join.getJ_Mday_M()); 
			pstmt.setString(15, join.getJ_Mday_D()); 
			pstmt.setInt(16, join.getJ_count()); 
			pstmt.setString(17, join.getJ_cost()); 
			pstmt.setInt(18, join.getJ_maxmem()); 
			pstmt.setInt(19, nowmem); //sql�뿉�꽌 default 媛� �븞癒뱀뼱�꽌 �뼲吏�濡� �씪�떒 1�쓣 二쇱뿀�뒿�땲�떎. �븘留� �떊泥��븯湲� 肄붾뱶 �옉�꽦�븷�븣 �닔�젙 �븘�슂�븷寃� 媛숈븘�슂�뀪
			pstmt.setString(20, join.getJ_content()); 
			pstmt.setString(21, join.getJ_pwd()); 
			pstmt.executeUpdate();
			
			re = 1;
			
			
		}catch(SQLException ex) {
			System.out.println("모집글에 대한 글쓰기 실패");
			ex.printStackTrace();
		}		
		finally {
			try{
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(Exception e){
				e.printStackTrace();
			}
		} 
		return re;
	}
	
	
//	由ы꽩���엯�씠 ArrayList �젣�꽕由� �뙆�씪誘명꽣 由ы꽩媛믪�  JoinBean�씤 listBoard 硫붿냼�뱶
//	湲�踰덊샇�� 湲� �궡�슜�쓣 由ы꽩�븯�뿬 �굹���깂
	public ArrayList<JoinBean> listBoard(String pageNumber) throws Exception{
		ArrayList<JoinBean> list = new ArrayList<JoinBean>();

		
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		ResultSet pageSet = null;
		
		
		int dbCount = 0;
		int absolutePage = 1;
		
		String sql= "SELECT j_idx\r\n" + //湲�踰덊샇
					"     , j_id\r\n" +  //�븘�씠�뵒
					"     , j_nickname\r\n" + 
					"     , j_city\r\n" + //�옣�냼 ��遺꾨쪟
					"     , j_location\r\n" +  	//5
					"     , j_hobbyB\r\n" + //痍⑤�� ��遺꾨쪟
					"     , j_hobbyS\r\n" + 
					"     , j_title\r\n" + 
					"     , j_date\r\n" + 
					"     , j_Dday_Y\r\n" + //留덇컧�씪�옄  //10
					"     , j_Dday_M\r\n" + 
					"     , j_Dday_D\r\n" + 
					"     , j_Mday_Y\r\n" + //留뚮굹�뒗 �궇
					"     , j_Mday_M\r\n" + 
					"     , j_Mday_D\r\n" + //15
					"     , j_count\r\n" + //議고쉶�닔
					"     , j_cost\r\n" + 
					"     , j_maxmem\r\n" + //理쒕��씤�썝
					"     , j_nowmem\r\n" + //�쁽�옱�씤�썝
					"     , j_content\r\n" + //20
					"     , j_pwd\r\n" + 
					"  FROM SEMI_JOINTABLE\r\n" + 
					" ORDER BY j_idx desc";
		
		String sql2= "SELECT COUNT(j_idx) FROM SEMI_JOINTABLE";
		
		try {
			conn = getConnection();
			stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
//			//而ㅼ꽌瑜� �듅�젙 �쐞移섎줈 �씠�룞�떆�궎湲� �쐞�빐 �궗�슜
			pageSet = stmt.executeQuery(sql2);
			
			
			
			// pageCount 媛믪쓣 �젙�븿
		
			if (pageSet.next()) {
				dbCount = pageSet.getInt(1);
				pageSet.close();
			}
			if (dbCount % JoinBean.pageSize == 0) {
				JoinBean.pageCount = dbCount / JoinBean.pageSize;
			} else {
				JoinBean.pageCount = dbCount / JoinBean.pageSize + 1;
			}
			if (pageNumber != null) {
				JoinBean.pageNum = Integer.parseInt(pageNumber);
				absolutePage = (JoinBean.pageNum - 1) * JoinBean.pageSize + 1;
			}
			
			
			rs = stmt.executeQuery(sql);
			
			
			
			if (rs.next()) {
				rs.absolute(absolutePage);
				
				int count = 0;
					
				
				while(count < JoinBean.pageSize) {
					//ArrayList�뿉 �떞�븘�빞 �빐�꽌 joinbean媛앹껜 �깮�꽦
					//join �깮�꽦�븯�뿬
					JoinBean join = new JoinBean();

					//寃곌낵媛� �꽭�똿(�떎 �꽭�똿�빐�넃�븘�빞吏� �굹以묒뿉 戮묒븘�벝�븣 �렪�븿)
					join.setJ_idx(rs.getInt(1));
					join.setJ_id(rs.getString(2));
					join.setJ_nickname(rs.getString(3));
					join.setJ_city(rs.getString(4));
					join.setJ_location (rs.getString(5));
					join.setJ_hobbyB (rs.getString(6));
					join.setJ_hobbyS(rs.getString(7));
					join.setJ_title(rs.getString(8));
					join.setJ_date(rs.getTimestamp(9));
					join.setJ_Dday_Y (rs.getString(10));//留덇컧�씪�옄
					join.setJ_Dday_M (rs.getString(11));
					join.setJ_Dday_D (rs.getString(12));
					join.setJ_Mday_Y(rs.getString(13));//留뚮굹�뒗 �궇
					join.setJ_Mday_M(rs.getString(14));
					join.setJ_Mday_D(rs.getString(15));
					join.setJ_count(rs.getInt(16));
					join.setJ_cost(rs.getString(17));
					join.setJ_maxmem (rs.getInt(18));
					join.setJ_nowmem(rs.getInt(19));
					join.setJ_content(rs.getString(20));
					join.setJ_pwd(rs.getString(21));
					
					//arraylist�뿉 ���옣
					list.add(join);
					
					if (rs.isLast()) {
						break;
					} else {
						rs.next();
					}
					
					count++;
//					count媛� 利앷� �릺�뼱�빞 10(pageSize)踰덉쓣 諛섎났�븿
				}
			}
		}catch(SQLException ex) {
			System.out.println("모집글list 표시 실패");
			ex.printStackTrace();
		}		
		finally {
			try{
				if(stmt != null) stmt.close();
				if(conn != null) conn.close();
			}catch(Exception e){
				e.printStackTrace();
			}
		} 
		return list;
	}
	
	// 由ы꽩���엯�씠 JoinBean�씤 getJoin 硫붿냼�뱶
	//湲�踰덊샇留� �꽆湲곕㈃ �븣�븘�꽌 �궡�슜�씠 �꽆�뼱媛��뒗 硫붿냼�뱶(利� 湲� 蹂닿린瑜� �쐞�빐�꽌 �궗�슜�븯�뒗 硫붿냼�뱶)
	//議고쉶 �닔 �븣臾몄뿉 遺꾧린泥섎━  �븘�슂
		public JoinBean getJoin(int j_idx, Boolean hit) throws Exception{
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			JoinBean join = new JoinBean();
			String sql = "";

			
			try {
				conn = getConnection();
				
				//李몄씪�븣 議고쉶�닔 利앷�(湲��쓣 蹂쇰븣留� 議고쉶�닔 �긽�듅. 
				//�닔�젙�븯嫄곕굹 �옉�꽦�븷�븣 議고쉶�닔 異붽� �븯吏� 紐삵븯�룄濡� boolean �궗�슜
				if(hit == true) {
				sql = "UPDATE SEMI_JOINTABLE SET j_count = j_count+1 WHERE j_idx = ?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, j_idx); 
				pstmt.executeUpdate();
				pstmt.close();
				
				sql ="		SELECT j_idx\r\n" + 
						"     , j_id\r\n" + 
						"     , j_nickname\r\n" + 
						"     , j_city\r\n" + 
						"     , j_location\r\n" + //5
						"     , j_hobbyB\r\n" + 
						"     , j_hobbyS\r\n" + 
						"     , j_title\r\n" + 
						"     , j_date\r\n" + 
						"     , j_Dday_Y\r\n" + //10
						"     , j_Dday_M\r\n" + 
						"     , j_Dday_D\r\n" + 
						"     , j_Mday_Y\r\n" + 
						"     , j_Mday_M\r\n" + 
						"     , j_Mday_D\r\n" + //15
						"     , j_count\r\n" + 
						"     , j_cost\r\n" + 
						"     , j_maxmem\r\n" + 
						"     , j_nowmem\r\n" + 
						"     , j_content\r\n" + //20
						"     , j_pwd\r\n" + 
						"  FROM SEMI_JOINTABLE\r\n" +
						" WHERE j_idx = ?";
				
				 
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, j_idx); 
				rs = pstmt.executeQuery();
				} else {
					sql ="		SELECT j_idx\r\n" + 
							"     , j_id\r\n" + 
							"     , j_nickname\r\n" + 
							"     , j_city\r\n" + 
							"     , j_location\r\n" + 
							"     , j_hobbyB\r\n" + 
							"     , j_hobbyS\r\n" + 
							"     , j_title\r\n" + 
							"     , j_date\r\n" + 
							"     , j_Dday_Y\r\n" + 
							"     , j_Dday_M\r\n" + 
							"     , j_Dday_D\r\n" + 
							"     , j_Mday_Y\r\n" + 
							"     , j_Mday_M\r\n" + 
							"     , j_Mday_D\r\n" +  
							"     , j_count\r\n" + 
							"     , j_cost\r\n" + 
							"     , j_maxmem\r\n" + 
							"     , j_nowmem\r\n" + 
							"     , j_content\r\n" + 
							"     , j_pwd\r\n" + 
							"  FROM SEMI_JOINTABLE\r\n" +
							" WHERE j_idx = ?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, j_idx); 
				rs = pstmt.executeQuery();	
				}
								
			if(rs.next()) {
				join.setJ_idx(rs.getInt("j_idx"));
				join.setJ_id(rs.getString("j_id"));
				join.setJ_nickname(rs.getString("j_nickname"));
				join.setJ_city(rs.getString("j_city"));
				join.setJ_location (rs.getString("j_location"));  //5
				join.setJ_hobbyB (rs.getString("j_hobbyB"));
				join.setJ_hobbyS(rs.getString("j_hobbyS"));
				join.setJ_title(rs.getString("j_title"));
				join.setJ_date(rs.getTimestamp("j_date"));
				join.setJ_Dday_Y (rs.getString("j_Dday_Y")); //10
				join.setJ_Dday_M (rs.getString("j_Dday_M"));
				join.setJ_Dday_D (rs.getString("j_Dday_D"));
				join.setJ_Mday_Y(rs.getString("j_Mday_Y"));
				join.setJ_Mday_M(rs.getString("j_Mday_M"));
				join.setJ_Mday_D(rs.getString("j_Mday_D"));//15
				join.setJ_count(rs.getInt("j_count"));
				join.setJ_cost(rs.getString("j_cost"));
				join.setJ_maxmem (rs.getInt("j_maxmem"));
				join.setJ_nowmem(rs.getInt("j_nowmem"));
				join.setJ_content(rs.getString("j_content"));//20
				join.setJ_pwd(rs.getString("j_pwd"));
				}
			
			}catch(SQLException ex) {
				System.out.println("모집글 내용 불러오기 실패");
				ex.printStackTrace();
			}		
			finally {
				try{
					if(pstmt != null) pstmt.close();
					if(conn != null) conn.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			} 
			return join;
		}
		
		
//		deleteJoin
		// BoardDBBean.java�뿉�꽌�뒗
		//public int deleteJoin(int idx, String pwd) throws Exception {濡� �옉�꽦�빐二쇱뀲�뒗�뜲 �씪�떒 �샊�떆 紐⑤Ⅴ�땲源�  洹몃�濡� �궗�슜�븷寃뚯슜
		
		//寃뚯떆湲� �궘�젣 硫붿냼�뱶 deleteJoin() 硫붿냼�뱶 => �궘�젣�븷 湲� 鍮꾨�踰덊샇 �솗�씤�븯�뒗 硫붿냼�뱶 
		public int deleteJoin(int idx, String pwd) throws Exception {
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			int result = -1;
			
			try {
				conn = getConnection();
				String sql="SELECT j_pwd FROM SEMI_JOINTABLE WHERE j_idx = ?";
				//湲� 踰덊샇�뿉 �뵲瑜� 鍮꾨�踰덊샇瑜� 異쒕젰�븯�뒗 荑쇰━臾�
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, idx); //媛믪쓣 吏묒뼱 �꽔�쓬(�쐞�쓽 荑쇰━�쓽 ?�뿉 �뱾�뼱媛�)
				rs = pstmt.executeQuery();
				
				if(rs.next()) {
					if(rs.getString("j_pwd").equals(pwd)) {
						sql="DELETE FROM SEMI_JOINTABLE WHERE j_idx = ?";
						pstmt = conn.prepareStatement(sql);
						pstmt.setInt(1, idx);
						pstmt.executeUpdate();	
						
						result = 1;
					} else {
						result = 2;
					}
				}				
				
			}catch(SQLException ex) {
				System.out.println("모집글 작성글 삭제 실패");
				ex.printStackTrace();
			}		
			finally {
				try{
					if(pstmt != null) pstmt.close();
					if(conn != null) conn.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			} 
			return result;			
		}
		
//		editJoin() 硫붿냼�뱶(寃뚯떆湲� �닔�젙 硫붿냼�뱶)
		public int editJoin(JoinBean join) throws Exception {
	         Connection conn = null;
	         PreparedStatement pstmt = null;
	         ResultSet rs = null;
	         int result = -1;
	         
	         try {
	            conn = getConnection();
	            String sql="SELECT j_pwd FROM SEMI_JOINTABLE WHERE j_idx = ?";
	            pstmt = conn.prepareStatement(sql);
	            pstmt.setInt(1, join.getJ_idx()); 
	            rs = pstmt.executeQuery();
	            
	            if(rs.next()) {
	               if(rs.getString("j_pwd").equals(join.getJ_pwd())) {
	                  sql="UPDATE SEMI_JOINTABLE SET  j_id=?\r\n" + 
	                           "                 , j_nickname=?\r\n" + 
	                           "                 , j_city=?\r\n" + 
	                           "                 , j_location=?\r\n" + 
	                           "                 , j_hobbyB=?\r\n" + 
	                           "                 , j_hobbyS=?\r\n" + 
	                           "                 , j_title=?\r\n" + 
	                           "              , j_Dday_Y=?\r\n" + 
	                           "                , j_Dday_M=?\r\n" + 
	                           "                 , j_Dday_D=?\r\n" +  
	                           "                 , j_Mday_Y=?\r\n" + 
	                           "              , j_Mday_M=?\r\n" + 
	                           "              , j_Mday_D=?\r\n" +  
	                           "                 , j_cost=?\r\n" + 
	                           "                 , j_maxmem=?\r\n" + 
	                           "                 , j_content=?\r\n" + 
	                           "                 , j_pwd=?\r\n" + 
	                           "             WHERE j_idx = ?"; 
	                  
	                  pstmt = conn.prepareStatement(sql);
	                  pstmt.setString(1, join.getJ_id());
	                  pstmt.setString(2, join.getJ_nickname());
	                  pstmt.setString(3, join.getJ_city());
	                  pstmt.setString(4, join.getJ_location());
	                  pstmt.setString(5, join.getJ_hobbyB());
	                  pstmt.setString(6, join.getJ_hobbyS());
	                  pstmt.setString(7, join.getJ_title());
	                  pstmt.setString(8, join.getJ_Dday_Y());
	                  pstmt.setString(9, join.getJ_Dday_M());
	                  pstmt.setString(10, join.getJ_Dday_D());
	                  pstmt.setString(11, join.getJ_Mday_Y());
	                  pstmt.setString(12, join.getJ_Mday_M());
	                  pstmt.setString(13, join.getJ_Mday_D());
	                  pstmt.setString(14, join.getJ_cost());
	                  pstmt.setInt(15, join.getJ_maxmem());
	                  pstmt.setString(16, join.getJ_content());
	                  pstmt.setString(17, join.getJ_pwd());
	                  pstmt.setInt(18, join.getJ_idx());
	                  pstmt.executeUpdate();   
              
	                  result = 1;
	               } else {
	                  result = 2;
	               }
	            }            
	            
	         }catch(SQLException ex) {
	            System.out.println("모집글의 수정 실패");
	            ex.printStackTrace();
	         }      
	         finally {
	            try{
	               if(pstmt != null) pstmt.close();
	               if(conn != null) conn.close();
	            }catch(Exception e){
	               e.printStackTrace();
	            }
	         } 
	         return result;            
	      } 
	
		public int insertApply(int j_idx, String u_id, String u_nickname) throws Exception{
		       Connection conn = null;
		       PreparedStatement pstmt = null;
		       PreparedStatement pstmt2 = null;
		       int re = -1;
		       
			   String sql1="UPDATE SEMI_JOINTABLE SET "
		                       +"  j_nowmem = j_nowmem+1"
		                       +"  WHERE j_idx = ?";//글번호에 대한 현재 인원 증가 쿼리
			   
//			   
//		       System.out.println("1@@@### ==> " + j_idx);
//		       System.out.println("1@@@### ==> " + u_id);
//		       System.out.println("1@@@### ==> " + u_nickname);
		       
		       String sql2 ="INSERT INTO SEMI_APPLYTABLE VALUES(?, ?, ?)";
		       
		       try {
		          conn = getConnection();

		          JoinBean join = JoinDBBean.getInstance().getJoin(j_idx, false);
		          UserBean user = UserDBBean.getInstance().getUser(u_id);
//		          
//		          System.out.println("2@@@### ==> " + join.getJ_idx());
//		          System.out.println("2@@@### ==> " + user.getU_id());
//		          System.out.println("2@@@### ==> " + user.getU_nickname());
//		          
		          pstmt = conn.prepareStatement(sql1);
		          pstmt.setInt(1,j_idx);
		          pstmt.executeUpdate();
		          
		          
		          pstmt2 = conn.prepareStatement(sql2);
		          pstmt2.setInt(1, join.getJ_idx());       
		          pstmt2.setString(2, user.getU_id()); 
		          pstmt2.setString(3, user.getU_nickname()); 
		          pstmt2.executeUpdate();
		          re = 1;

		       }catch(SQLException ex) {
		          System.out.println("모집글에 대한 신청하기 및 APPLYTALBE에 데이터 추가 실패");
		          ex.printStackTrace();
		       }      
		       finally {
		          try{
		             if(pstmt != null) pstmt.close();
		             if(conn != null) conn.close();
		          }catch(Exception e){
		             e.printStackTrace();
		          }
		       } 
		       return re;
		    }
			
		
}




