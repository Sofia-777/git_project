package semi_join;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import semi_board.BoardBean;
import semi_user.UserBean;
import semi_user.UserDBBean;

public class JoinDBBean {
	private static JoinDBBean instance = new JoinDBBean();
   
	public static JoinDBBean getInstance() {
		return instance;
	}
	 
	public Connection getConnection() throws Exception {
		Context ctx = new InitialContext();
		DataSource ds = (DataSource)ctx.lookup("java:comp/env/jdbc/oracle");
		return ds.getConnection();
	}
	
	// ������ �ۼ�
	public int insertJoin(JoinBean join) throws Exception{
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int re = -1;
		
		// ������ �ۼ� �� ��ȣ �˾ƺ���
		String sql = "SELECT MAX(j_idx) FROM SEMI_JOINTABLE";
		
		// �� ��ȣ 
		int number = 1;
		// ���� �ο� ��������
		int nowmem = join.getJ_nowmem();
		// �ۼ��� ���ڸ��� ������ �� �� ���⶧���� 1�� ����
		int end = 1;
	      
	try {
		conn = getConnection();
		pstmt = conn.prepareStatement(sql);
		rs = pstmt.executeQuery();
	         
		// ���� �� ��ȣ�� �ִٸ�
		if(rs.next()) {
			// �� ���� ��ȣ �ο�
			number = rs.getInt("MAX(j_idx)")+1;   
		} 
		
		else {
			// ���ٸ� 1�� �۷� ����
			number = 1;
		}
			// ���� �ο��� �ۼ� �ʰ� ���ÿ� 1����
			nowmem = 1;

			sql="INSERT INTO SEMI_JOINTABLE VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	         
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, number);
			pstmt.setString(2, join.getJ_id()); 
			pstmt.setString(3, join.getJ_nickname());
			pstmt.setString(4, join.getJ_city()); 
			pstmt.setString(5, join.getJ_location()); 
			pstmt.setString(6, join.getJ_hobbyB()); 
			pstmt.setString(7, join.getJ_hobbyS()); 
			pstmt.setString(8, join.getJ_title()); 
			pstmt.setTimestamp(9, join.getJ_date());
			pstmt.setString(10, join.getJ_Dday());
			pstmt.setString(11, join.getJ_Mday());
			pstmt.setInt(12, join.getJ_count()); 
			pstmt.setString(13, join.getJ_cost()); 
			pstmt.setInt(14, join.getJ_maxmem()); 
			pstmt.setInt(15, nowmem);
			pstmt.setString(16, join.getJ_content()); 
			pstmt.setString(17, join.getJ_pwd()); 
			pstmt.setInt(18, end); 
			pstmt.executeUpdate();
	         
			re = 1;
		} catch(SQLException ex) {
			System.out.println("������ �ۼ� ����");
			ex.printStackTrace();
		} finally {
			try{
				if(rs != null) rs.close();
	            if(pstmt != null) pstmt.close();
	            if(conn != null) conn.close();
	         } catch(Exception e){
	        	 e.printStackTrace();
	         }
		} 
	
		return re;
	}
	
	// ������ ����Ʈ �ҷ�����
	public ArrayList<JoinBean> listBoard(String pageNumber) throws Exception{
		ArrayList<JoinBean> list = new ArrayList<JoinBean>();
	      
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		ResultSet pageSet = null;
	      
		int dbCount = 0;
		int absolutePage = 1;
  
		String sql= "SELECT j_idx, "
				+ " j_nickname,"
				+ " j_city,"
				+ " j_hobbyB,"
				+ " j_title,"
				+ " j_Dday,"
				+ " j_Mday,"
				+ " j_count,"
				+ " j_maxmem,"
				+ " j_nowmem, "
				+ " j_end "
				+ " FROM SEMI_JOINTABLE "
				+ " ORDER BY j_Dday asc";
	
		String sql2= "SELECT COUNT(j_idx) FROM SEMI_JOINTABLE";
	      
		try {
			conn = getConnection();
			stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
			pageSet = stmt.executeQuery(sql2);
	      
			if (pageSet.next()) {
				dbCount = pageSet.getInt(1);
				pageSet.close();
			}
			
			if (dbCount % JoinBean.pageSize == 0) {
				JoinBean.pageCount = dbCount / JoinBean.pageSize;
			} 
			
			else {
				JoinBean.pageCount = dbCount / JoinBean.pageSize + 1;
			}
	         
			if (pageNumber != null) {
				JoinBean.pageNum = Integer.parseInt(pageNumber);
	            absolutePage = (JoinBean.pageNum - 1) * JoinBean.pageSize + 1;
			}
	         
			rs = stmt.executeQuery(sql);
		         
			if (rs.next()) {
				rs.absolute(absolutePage);
	            
				int count = 0;
	            
	            while(count < JoinBean.pageSize) {
	            	JoinBean join = new JoinBean();

	            	join.setJ_idx(rs.getInt(1));
	            	join.setJ_nickname(rs.getString(2));
	            	join.setJ_city(rs.getString(3));
	            	join.setJ_hobbyB (rs.getString(4));
	            	join.setJ_title(rs.getString(5));
	            	join.setJ_Dday(rs.getString(6));
	            	join.setJ_Mday(rs.getString(7));
	            	join.setJ_count(rs.getInt(8));
	            	join.setJ_maxmem (rs.getInt(9));
	            	join.setJ_nowmem(rs.getInt(10));
	            	join.setJ_end(rs.getInt(11));
	               
	            	list.add(join);
	               
	            	if (rs.isLast()) {
	            		break;
	            	} 
	            	
	            	else {
	            		rs.next();
	            	}
	               
	            	count++;
	            }
			}
		}catch(SQLException ex) {
			System.out.println("������ ��� ��ȸ ����");
			ex.printStackTrace();
		} finally {
			try{
				if(rs != null) rs.close();
				if(stmt != null) stmt.close();
	            if(conn != null) conn.close();
			}catch(Exception e){
				e.printStackTrace();
			}
		} 
		
		return list;
	}
	   
	// ������ ����
	public JoinBean getJoin(int j_idx, Boolean hit) throws Exception{
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		JoinBean join = new JoinBean();
		String sql = "";
	         
		try {
			conn = getConnection();
	            
			if(hit == true) {
				sql = "UPDATE SEMI_JOINTABLE SET j_count = j_count+1 WHERE j_idx = ?";
	            pstmt = conn.prepareStatement(sql);
	            pstmt.setInt(1, j_idx); 
	            pstmt.executeUpdate();
	            pstmt.close();
	            
	            sql = "SELECT j_idx, "
	            	+ "j_id, "
	            	+ "j_nickname, "
		            + "j_city, "
		            + "j_location, "
		            + "j_hobbyB, "
		            + "j_hobbyS, "
		            + "j_title, "
		            + "j_date, "
		            + "j_Dday, "
		            + "j_Mday, "
		            + "j_count, "
		            + "j_cost, "
		            + "j_maxmem, "
		            + "j_nowmem, "
		            + "j_content, "
		            + "j_pwd, "
		            + "j_end "
		            + "FROM SEMI_JOINTABLE "
		            + "WHERE j_idx = ?";
	             
	            pstmt = conn.prepareStatement(sql);
	            pstmt.setInt(1, j_idx); 
	            rs = pstmt.executeQuery();
			} 
			
			else {
				sql = "SELECT j_idx, "
					+ "j_id, "
		            + "j_nickname, "
			        + "j_city, "
			        + "j_location, "
			        + "j_hobbyB, "
		            + "j_hobbyS, "
		            + "j_title, "
		            + "j_date, "
		            + "j_Dday, "
		            + "j_Mday, "
		            + "j_count, "
		            + "j_cost, "
		            + "j_maxmem, "
		            + "j_nowmem, "
		            + "j_content, "
		            + "j_pwd, "
		            + "j_end "
		            + "FROM SEMI_JOINTABLE "
		            + "WHERE j_idx = ?";
				
	            pstmt = conn.prepareStatement(sql);
	            pstmt.setInt(1, j_idx); 
	            rs = pstmt.executeQuery();   
			}
	                        
			if(rs.next()) {
	            join.setJ_idx(rs.getInt("j_idx"));
	            join.setJ_id(rs.getString("j_id"));
	            join.setJ_nickname(rs.getString("j_nickname"));
	            join.setJ_city(rs.getString("j_city"));
	            join.setJ_location (rs.getString("j_location"));  
	            join.setJ_hobbyB (rs.getString("j_hobbyB"));
	            join.setJ_hobbyS(rs.getString("j_hobbyS"));
	            join.setJ_title(rs.getString("j_title"));
	            join.setJ_date(rs.getTimestamp("j_date"));
	            join.setJ_Dday(rs.getString("j_Dday")); 
	            join.setJ_Mday(rs.getString("j_Mday"));
	            join.setJ_count(rs.getInt("j_count"));
	            join.setJ_cost(rs.getString("j_cost"));
	            join.setJ_maxmem (rs.getInt("j_maxmem"));
	            join.setJ_nowmem(rs.getInt("j_nowmem"));
	            join.setJ_content(rs.getString("j_content"));
	            join.setJ_pwd(rs.getString("j_pwd"));
	            join.setJ_end(rs.getInt("j_end"));
			}
		}catch(SQLException ex) {
			System.out.println("������ ��ȸ ����");
			ex.printStackTrace();
		} finally {
			try{
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(Exception e){
				e.printStackTrace();
			}
		} 
		
		return join;
	}
	      
	// ������ ����
	public int deleteJoin(int idx, String pwd) throws Exception {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		// ���� ���� �Ǵ�
		int result = -1;
	         
		try {
			conn = getConnection();
			String sql="SELECT j_pwd FROM SEMI_JOINTABLE WHERE j_idx = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, idx); 
			rs = pstmt.executeQuery();
	            
			if(rs.next()) {
				if(rs.getString("j_pwd").equals(pwd)) {
					sql="DELETE FROM SEMI_JOINTABLE WHERE j_idx = ?";
					pstmt = conn.prepareStatement(sql);
					pstmt.setInt(1, idx);
					pstmt.executeUpdate();   
	                  
					result = 1;
				} 
				
				else {
					result = 2;
				}
			} 
		}catch(SQLException ex) {
			System.out.println("������ ���� ����");
			ex.printStackTrace();
		} finally {
			try{
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(Exception e){
				e.printStackTrace();
			}
		} 
		
		return result;         
	}
	
	// ������ ����
	public int editJoin(JoinBean join) throws Exception {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		// ������ ���� ��� �Ǵ� ����
		int result = -1;
	         
		try {
			conn = getConnection();
			String sql="SELECT j_pwd FROM SEMI_JOINTABLE WHERE j_idx = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, join.getJ_idx()); 
			rs = pstmt.executeQuery();
	            
			if(rs.next()) {
				if(rs.getString("j_pwd").equals(join.getJ_pwd())) {
					sql = "UPDATE SEMI_JOINTABLE SET " 
				            + "j_nickname, "
					        + "j_city, "
					        + "j_location, "
					        + "j_hobbyB, "
				            + "j_hobbyS, "
				            + "j_title, "
				            + "j_date, "
				            + "j_Dday, "
				            + "j_Mday, "
				            + "j_cost, "
				            + "j_maxmem, "
				            + "j_content, "
				            + "j_pwd "
				            + "FROM SEMI_JOINTABLE "
				            + "WHERE j_idx = ?";
	                  
					pstmt = conn.prepareStatement(sql);
					pstmt.setString(1, join.getJ_nickname());
					pstmt.setString(2, join.getJ_city());
					pstmt.setString(3, join.getJ_location());
					pstmt.setString(4, join.getJ_hobbyB());
					pstmt.setString(5, join.getJ_hobbyS());
					pstmt.setString(6, join.getJ_title());
					pstmt.setTimestamp(7, join.getJ_date());
					pstmt.setString(8, join.getJ_Dday());
					pstmt.setString(9, join.getJ_Mday());
					pstmt.setString(10, join.getJ_cost());
					pstmt.setInt(11, join.getJ_maxmem());
					pstmt.setString(12, join.getJ_content());
					pstmt.setString(13, join.getJ_pwd());
					pstmt.setInt(14, join.getJ_idx());
					pstmt.executeUpdate();   
		               
					result = 1;
				} 
				
				else {
					result = 2;
				}
			}            
		}catch(SQLException ex) {
			System.out.println("���� ����");
			ex.printStackTrace();
		} finally {
			try{
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(Exception e){
				e.printStackTrace();
			}
		} 
	
		return result;
	} 
	
	// ������ ����
	public int insertApply(int j_idx, String u_id, String u_nickname) throws Exception{
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		int result = 0;
		String sql = "";
         
        try {
        	conn = getConnection();

        	sql = "SELECT j_idx, "
					+ "j_id, "
		            + "j_nickname, "
			        + "j_city, "
			        + "j_location, "
			        + "j_hobbyB, "
		            + "j_hobbyS, "
		            + "j_title, "
		            + "j_date, "
		            + "j_Dday, "
		            + "j_Mday, "
		            + "j_count, "
		            + "j_cost, "
		            + "j_maxmem, "
		            + "j_nowmem, "
		            + "j_content "
		            + "FROM SEMI_JOINTABLE "
		            + "WHERE j_idx = ?";
        	
        	pstmt = conn.prepareStatement(sql);
        	pstmt.setInt(1,j_idx);
        	rs = pstmt.executeQuery();
        	
        	if(rs.next()) {
        		Date day = new Date();
        		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        		
        		String today = sdf.format(day);
        		
        		JoinBean join = JoinDBBean.getInstance().getJoin(j_idx, false);
        		String j_Dday = join.getJ_Dday().substring(0, 10);

        		// ������¥�� ������ ��� ���� ����
        		if(j_Dday.equals(today)) {
        			join.setJ_end(0);
        			result = 1;
        		}
        		
        		else {
        			// ���� �ο��� �ִ� �ο��� ���� ���
        			if(join.getJ_nowmem() == join.getJ_maxmem()) {
        				join.setJ_end(0);
        				result = 2;
        			}
        			
        			else { 
        				// �̹� ������ �� ���
        				sql = "SELECT ap_id FROM SEMI_APPLYTABLE WHERE ap_bidx = ?";
        				pstmt = conn.prepareStatement(sql);
        				pstmt.setInt(1, j_idx);
        				rs = pstmt.executeQuery();
        				
        				if(rs.next()) {
        					sql = "DELETE FROM SEMI_APPLYTABLE WHERE ap_id = ? and ap_bidx = ?";
        					pstmt = conn.prepareStatement(sql);
        					pstmt.setString(1, u_id);
        					pstmt.setInt(2, j_idx);       
        					pstmt.executeUpdate(); 
        					
        					sql = "UPDATE SEMI_JOINTABLE SET "
    								+ "j_nowmem = j_nowmem - 1 "
    								+ "WHERE j_idx = ?";
    						
    						pstmt = conn.prepareStatement(sql);
    						pstmt.setInt(1, join.getJ_idx());
    						pstmt.executeUpdate();
        					
        					result = 3;
        				}
        				
        				else {
        					
        					sql ="INSERT INTO SEMI_APPLYTABLE VALUES(?, ?, ?)";
    						
    						pstmt = conn.prepareStatement(sql);
    						pstmt.setInt(1, j_idx);       
    						pstmt.setString(2, u_id); 
    						pstmt.setString(3, u_nickname); 
    						pstmt.executeUpdate();
    						
    						sql = "UPDATE SEMI_JOINTABLE SET "
    								+ "j_nowmem = j_nowmem + 1 "
    								+ "WHERE j_idx = ?";
    						
    						pstmt = conn.prepareStatement(sql);
    						pstmt.setInt(1, join.getJ_idx());
    						pstmt.executeUpdate();
    						
        					result = 4;
        				}
        			}
        		}
        	}
        }catch(SQLException ex) {
        	System.out.println("������ ���� ����");
        	ex.printStackTrace();
        } finally {
        	try{
        		if(pstmt != null) pstmt.close();
        		if(conn != null) conn.close();
        	}catch(Exception e){
        		e.printStackTrace();
        	}
        } 
        
        System.out.println("@@@### result ===> " + result);
        return result;
	}
}