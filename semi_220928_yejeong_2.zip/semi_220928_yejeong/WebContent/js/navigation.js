function changeBg(){
    var navbar = document.getElementById('navbar');
    var scrollValue = window.scrollY;
    console.log(scrollValue);

    if (scrollValue < 900) {
        navbar.classList.add('bgColor1');
        navbar.classList.remove('bgColor');
    } else if (900<scrollValue&&scrollValue<1800) {
        navbar.classList.remove('bgColor1');
    }
    else{
        navbar.classList.remove('bgColor1');
        navbar.classList.add('bgColor');
    }
}

window.addEventListener('scroll',changeBg)