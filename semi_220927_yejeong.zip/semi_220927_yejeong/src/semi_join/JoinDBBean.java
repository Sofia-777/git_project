package semi_join;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class JoinDBBean {
	private static JoinDBBean instance = new JoinDBBean();
   
	public static JoinDBBean getInstance() {
		return instance;
	}
	 
	public Connection getConnection() throws Exception {
		Context ctx = new InitialContext();
		DataSource ds = (DataSource)ctx.lookup("java:comp/env/jdbc/oracle");
		return ds.getConnection();
	}
	
	public int insertJoin(JoinBean join) throws Exception{
		int re = -1;
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql="SELECT MAX(j_idx) FROM SEMI_JOINTABLE";
		int number=1;
		int nowmem=join.getJ_nowmem();
		int idx = join.getJ_idx();
	      
	      
	try {
		conn = getConnection();
		pstmt = conn.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
	         
		if(rs.next()) {
			number=rs.getInt("MAX(j_idx)")+1;   
	         
		} 
		
		else {
			number = 1;
		}
			nowmem =1;

			sql="INSERT INTO SEMI_JOINTABLE VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ,?, ?, ?, ?, ?, ?, ?, ?, ?)";
	         
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, number);
			pstmt.setString(2, join.getJ_id()); 
			pstmt.setString(3, join.getJ_nickname());
			pstmt.setString(4, join.getJ_city()); 
			pstmt.setString(5, join.getJ_location()); 
			pstmt.setString(6, join.getJ_hobbyB()); 
			pstmt.setString(7, join.getJ_hobbyS()); 
			pstmt.setString(8, join.getJ_title()); 
			pstmt.setTimestamp(9, join.getJ_date()); 
			pstmt.setString(10, join.getJ_Dday_Y()); 
			pstmt.setString(11, join.getJ_Dday_M()); 
			pstmt.setString(12, join.getJ_Dday_D()); 
			pstmt.setString(13, join.getJ_Mday_Y()); 
			pstmt.setString(14, join.getJ_Mday_M()); 
			pstmt.setString(15, join.getJ_Mday_D()); 
			pstmt.setInt(16, join.getJ_count()); 
			pstmt.setString(17, join.getJ_cost()); 
			pstmt.setInt(18, join.getJ_maxmem()); 
			pstmt.setInt(19, nowmem);
			pstmt.setString(20, join.getJ_content()); 
			pstmt.setString(21, join.getJ_pwd()); 
			pstmt.executeUpdate();
	         
			re = 1;
		} catch(SQLException ex) {
			System.out.println("추�   �� ��");
			ex.printStackTrace();
		} finally {
			try{
	            if(pstmt != null) pstmt.close();
	            if(conn != null) conn.close();
	         } catch(Exception e){
	        	 e.printStackTrace();
	         }
		} 
		return re;
	}
	
	public ArrayList<JoinBean> listBoard(String pageNumber) throws Exception{
	      Connection conn = null;
	      Statement stmt = null;
	      ResultSet rs = null;
	      ResultSet pageSet = null;
	      
	      int dbCount = 0;
	      int absolutePage = 1;
	      
	      String sql= "SELECT j_idx\r\n" + 
	               "     , j_id\r\n" +  
	               "     , j_nickname\r\n" + 
	               "     , j_city\r\n" + 
	               "     , j_location\r\n" +    
	               "     , j_hobbyB\r\n" + 
	               "     , j_hobbyS\r\n" + 
	               "     , j_title\r\n" + 
	               "     , j_date\r\n" + 
	               "     , j_Dday_Y\r\n" + 
	               "     , j_Dday_M\r\n" + 
	               "     , j_Dday_D\r\n" + 
	               "     , j_Mday_Y\r\n" + 
	               "     , j_Mday_M\r\n" + 
	               "     , j_Mday_D\r\n" + 
	               "     , j_count\r\n" + 
	               "     , j_cost\r\n" + 
	               "     , j_maxmem\r\n" + 
	               "     , j_nowmem\r\n" + 
	               "     , j_content\r\n" + 
	               "     , j_pwd\r\n" + 
	               "  FROM SEMI_JOINTABLE\r\n" + 
	               " ORDER BY j_idx desc";
	      
	      String sql2= "SELECT COUNT(j_idx) FROM SEMI_JOINTABLE";
	      ArrayList<JoinBean> list = new ArrayList<JoinBean>();
	      
	      try {
	         conn = getConnection();
	         stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
	         pageSet = stmt.executeQuery(sql2);
	      
	         if (pageSet.next()) {
	            dbCount = pageSet.getInt(1);
	            pageSet.close();
	         }
	         if (dbCount % JoinBean.pageSize == 0) {
	            JoinBean.pageCount = dbCount / JoinBean.pageSize;
	         } else {
	            JoinBean.pageCount = dbCount / JoinBean.pageSize + 1;
	         }
	         if (pageNumber != null) {
	            JoinBean.pageNum = Integer.parseInt(pageNumber);
	            absolutePage = (JoinBean.pageNum - 1) * JoinBean.pageSize + 1;
	         }
	         
	         rs = stmt.executeQuery(sql);
	         
	         if (rs.next()) {
	            rs.absolute(absolutePage);
	            
	            int count = 0;
	            
	            while(count < JoinBean.pageSize) {
	               JoinBean join = new JoinBean();

	               join.setJ_idx(rs.getInt(1));
	               join.setJ_id(rs.getString(2));
	               join.setJ_nickname(rs.getString(3));
	               join.setJ_city(rs.getString(4));
	               join.setJ_location (rs.getString(5));
	               join.setJ_hobbyB (rs.getString(6));
	               join.setJ_hobbyS(rs.getString(7));
	               join.setJ_title(rs.getString(8));
	               join.setJ_date(rs.getTimestamp(9));
	               join.setJ_Dday_Y (rs.getString(10));
	               join.setJ_Dday_M (rs.getString(11));
	               join.setJ_Dday_D (rs.getString(12));
	               join.setJ_Mday_Y(rs.getString(13));
	               join.setJ_Mday_M(rs.getString(14));
	               join.setJ_Mday_D(rs.getString(15));
	               join.setJ_count(rs.getInt(16));
	               join.setJ_cost(rs.getString(17));
	               join.setJ_maxmem (rs.getInt(18));
	               join.setJ_nowmem(rs.getInt(19));
	               join.setJ_content(rs.getString(20));
	               join.setJ_pwd(rs.getString(21));
	               
	               list.add(join);
	               
	               if (rs.isLast()) {
	                  break;
	               } else {
	                  rs.next();
	               }
	               
	               count++;
	            }
	         }
	      }catch(SQLException ex) {
	         System.out.println("리스 ��  �� ��");
	         ex.printStackTrace();
	      }      
	      finally {
	         try{
	            if(stmt != null) stmt.close();
	            if(conn != null) conn.close();
	         }catch(Exception e){
	            e.printStackTrace();
	         }
	      } 
	      return list;
	   }
	   
	      public JoinBean getJoin(int j_idx, Boolean hit) throws Exception{
	         Connection conn = null;
	         PreparedStatement pstmt = null;
	         ResultSet rs = null;
	         JoinBean join = new JoinBean();
	         String sql = "";

	         
	         try {
	            conn = getConnection();
	            
	            if(hit == true) {
	            sql = "UPDATE SEMI_JOINTABLE SET j_count = j_count+1 WHERE j_idx = ?";
	            pstmt = conn.prepareStatement(sql);
	            pstmt.setInt(1, j_idx); 
	            pstmt.executeUpdate();
	            pstmt.close();
	            
	            sql ="      SELECT j_idx\r\n" + 
	                  "     , j_id\r\n" + 
	                  "     , j_nickname\r\n" + 
	                  "     , j_city\r\n" + 
	                  "     , j_location\r\n" + 
	                  "     , j_hobbyB\r\n" + 
	                  "     , j_hobbyS\r\n" + 
	                  "     , j_title\r\n" + 
	                  "     , j_date\r\n" + 
	                  "     , j_Dday_Y\r\n" + 
	                  "     , j_Dday_M\r\n" + 
	                  "     , j_Dday_D\r\n" + 
	                  "     , j_Mday_Y\r\n" + 
	                  "     , j_Mday_M\r\n" + 
	                  "     , j_Mday_D\r\n" + 
	                  "     , j_count\r\n" + 
	                  "     , j_cost\r\n" + 
	                  "     , j_maxmem\r\n" + 
	                  "     , j_nowmem\r\n" + 
	                  "     , j_content\r\n" + //20
	                  "     , j_pwd\r\n" + 
	                  "  FROM SEMI_JOINTABLE\r\n" +
	                  " WHERE j_idx = ?";
	            
	             
	            pstmt = conn.prepareStatement(sql);
	            pstmt.setInt(1, j_idx); 
	            rs = pstmt.executeQuery();
	            } else {
	               sql ="      SELECT j_idx\r\n" + 
	                     "     , j_id\r\n" + 
	                     "     , j_nickname\r\n" + 
	                     "     , j_city\r\n" + 
	                     "     , j_location\r\n" + 
	                     "     , j_hobbyB\r\n" + 
	                     "     , j_hobbyS\r\n" + 
	                     "     , j_title\r\n" + 
	                     "     , j_date\r\n" + 
	                     "     , j_Dday_Y\r\n" + 
	                     "     , j_Dday_M\r\n" + 
	                     "     , j_Dday_D\r\n" + 
	                     "     , j_Mday_Y\r\n" + 
	                     "     , j_Mday_M\r\n" + 
	                     "     , j_Mday_D\r\n" +  
	                     "     , j_count\r\n" + 
	                     "     , j_cost\r\n" + 
	                     "     , j_maxmem\r\n" + 
	                     "     , j_nowmem\r\n" + 
	                     "     , j_content\r\n" + 
	                     "     , j_pwd\r\n" + 
	                     "  FROM SEMI_JOINTABLE\r\n" +
	                     " WHERE j_idx = ?";
	            pstmt = conn.prepareStatement(sql);
	            pstmt.setInt(1, j_idx); 
	            rs = pstmt.executeQuery();   
	            }
	                        
	         if(rs.next()) {
	            join.setJ_idx(rs.getInt("j_idx"));
	            join.setJ_id(rs.getString("j_id"));
	            join.setJ_nickname(rs.getString("j_nickname"));
	            join.setJ_city(rs.getString("j_city"));
	            join.setJ_location (rs.getString("j_location"));  
	            join.setJ_hobbyB (rs.getString("j_hobbyB"));
	            join.setJ_hobbyS(rs.getString("j_hobbyS"));
	            join.setJ_title(rs.getString("j_title"));
	            join.setJ_date(rs.getTimestamp("j_date"));
	            join.setJ_Dday_Y (rs.getString("j_Dday_Y")); 
	            join.setJ_Dday_M (rs.getString("j_Dday_M"));
	            join.setJ_Dday_D (rs.getString("j_Dday_D"));
	            join.setJ_Mday_Y(rs.getString("j_Mday_Y"));
	            join.setJ_Mday_M(rs.getString("j_Mday_M"));
	            join.setJ_Mday_D(rs.getString("j_Mday_D"));
	            join.setJ_count(rs.getInt("j_count"));
	            join.setJ_cost(rs.getString("j_cost"));
	            join.setJ_maxmem (rs.getInt("j_maxmem"));
	            join.setJ_nowmem(rs.getInt("j_nowmem"));
	            join.setJ_content(rs.getString("j_content"));
	            join.setJ_pwd(rs.getString("j_pwd"));
	            }
	         
	         }catch(SQLException ex) {
	            System.out.println(" �� �� 불러 ���   �� ��!");
	            ex.printStackTrace();
	         }      
	         finally {
	            try{
	               if(pstmt != null) pstmt.close();
	               if(conn != null) conn.close();
	            }catch(Exception e){
	               e.printStackTrace();
	            }
	         } 
	         return join;
	      }
	      
	      public int deleteJoin(int idx, String pwd) throws Exception {
	         Connection conn = null;
	         PreparedStatement pstmt = null;
	         ResultSet rs = null;
	         int result = -1;
	         
	         try {
	            conn = getConnection();
	            String sql="SELECT j_pwd FROM SEMI_JOINTABLE WHERE j_idx = ?";
	            pstmt = conn.prepareStatement(sql);
	            pstmt.setInt(1, idx); 
	            rs = pstmt.executeQuery();
	            
	            if(rs.next()) {
	               if(rs.getString("j_pwd").equals(pwd)) {
	                  sql="DELETE FROM SEMI_JOINTABLE WHERE j_idx = ?";
	                  pstmt = conn.prepareStatement(sql);
	                  pstmt.setInt(1, idx);
	                  pstmt.executeUpdate();   
	                  
	                  result = 1;
	               } else {
	                  result = 2;
	               }
	            }            
	            
	         }catch(SQLException ex) {
	            System.out.println(" �� ��  �� ��");
	            ex.printStackTrace();
	         }      
	         finally {
	            try{
	               if(pstmt != null) pstmt.close();
	               if(conn != null) conn.close();
	            }catch(Exception e){
	               e.printStackTrace();
	            }
	         } 
	         return result;         
	      }
	      
	      public int editJoin(JoinBean join) throws Exception {
	         Connection conn = null;
	         PreparedStatement pstmt = null;
	         ResultSet rs = null;
	         int result = -1;
	         
	         try {
	            conn = getConnection();
	            String sql="SELECT j_pwd FROM SEMI_JOINTABLE WHERE j_idx = ?";
	            pstmt = conn.prepareStatement(sql);
	            pstmt.setInt(1, join.getJ_idx()); 
	            rs = pstmt.executeQuery();
	            
	            if(rs.next()) {
	               if(rs.getString("j_pwd").equals(join.getJ_pwd())) {
	                  sql="UPDATE SEMI_JOINTABLE SET  j_id=?\r\n" + 
	                           "                 , j_nickname=?\r\n" + 
	                           "                 , j_city=?\r\n" + 
	                           "                 , j_location=?\r\n" + 
	                           "                 , j_hobbyB=?\r\n" + 
	                           "                 , j_hobbyS=?\r\n" + 
	                           "                 , j_title=?\r\n" + 
	                           "              , j_Dday_Y=?\r\n" + 
	                           "                , j_Dday_M=?\r\n" + 
	                           "                 , j_Dday_D=?\r\n" +  
	                           "                 , j_Mday_Y=?\r\n" + 
	                           "              , j_Mday_M=?\r\n" + 
	                           "              , j_Mday_D=?\r\n" +  
	                           "                 , j_cost=?\r\n" + 
	                           "                 , j_maxmem=?\r\n" + 
	                           "                 , j_content=?\r\n" + 
	                           "                 , j_pwd=?\r\n" + 
	                           "             WHERE j_idx = ?"; 
	                  
	                  pstmt = conn.prepareStatement(sql);
	                  pstmt.setString(1, join.getJ_id());
	                  pstmt.setString(2, join.getJ_nickname());
	                  pstmt.setString(3, join.getJ_city());
	                  pstmt.setString(4, join.getJ_location());
	                  pstmt.setString(5, join.getJ_hobbyB());
	                  pstmt.setString(6, join.getJ_hobbyS());
	                  pstmt.setString(7, join.getJ_title());
	                  pstmt.setString(8, join.getJ_Dday_Y());
	                  pstmt.setString(9, join.getJ_Dday_M());
	                  pstmt.setString(10, join.getJ_Dday_D());
	                  pstmt.setString(11, join.getJ_Mday_Y());
	                  pstmt.setString(12, join.getJ_Mday_M());
	                  pstmt.setString(13, join.getJ_Mday_D());
	                  pstmt.setString(14, join.getJ_cost());
	                  pstmt.setInt(15, join.getJ_maxmem());
	                  pstmt.setString(16, join.getJ_content());
	                  pstmt.setString(17, join.getJ_pwd());
	                  pstmt.setInt(18, join.getJ_idx());
	                  pstmt.executeUpdate();   
               
	                  result = 1;
	               } else {
	                  result = 2;
	               }
	            }            
	            
	         }catch(SQLException ex) {
	            System.out.println("���� ����");
	            ex.printStackTrace();
	         }      
	         finally {
	            try{
	               if(pstmt != null) pstmt.close();
	               if(conn != null) conn.close();
	            }catch(Exception e){
	               e.printStackTrace();
	            }
	         } 
	         return result;            
	      }   
}