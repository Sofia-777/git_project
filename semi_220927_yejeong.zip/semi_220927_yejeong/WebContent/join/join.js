function check_ok() {
	if(join_frm.j_city.value.length == 0){	
		alert("장소 대분류를 입력하세요.");
		join_frm.j_city.focus();
		return;
	} 
	if(join_frm.j_location.value.length == 0){	
		alert("장소 소분류를 입력하세요.");
		join_frm.j_location.focus();
		return;
	} 
	if(join_frm.j_hobbyB.value.length == 0){	
		alert("취미 대분류를 입력하세요.");
		join_frm.j_hobbyB.focus();
		return;
	} 
	if(join_frm.j_hobbyS.value.length == 0){	
		alert("취미 소분류를 입력하세요.");
		join_frm.j_hobbyS.focus();
		return;
	} 
	if(join_frm.j_Dday_Y.value.length == 0){	
		alert("마감 일자 년도를 입력하세요.");
		join_frm.j_Dday_Y.focus();
		return;
	} 
	if(join_frm.j_Dday_M.value.length == 0){	
		alert("마감 일자 월을 입력하세요.");
		join_frm.j_Dday_M.focus();
		return;
	} 
	if(join_frm.j_Dday_D.value.length == 0){	
		alert("마감 일자 일자를 입력하세요.");
		join_frm.j_Dday_D.focus();
		return;
	} 
	
	if(join_frm.j_Mday_Y.value.length == 0){	
		alert("만나는 날 년도를 입력하세요.");
		join_frm.j_Mday_Y.focus();
		return;
	} 
	if(join_frm.j_Mday_M.value.length == 0){	
		alert("만나는 날 월을 입력하세요.");
		join_frm.j_Mday_M.focus();
		return;
	} 
	if(join_frm.j_Mday_D.value.length == 0){	
		alert("만나는 날 일자를 입력하세요.");
		join_frm.j_Mday_D.focus();
		return;
	} 
	if(join_frm.j_cost.value.length == 0){	
		alert("비용 유무를 입력하세요.");
		join_frm.j_cost.focus();
		return;
	} 
	if(join_frm.j_maxmem.value.length == 0){	
		alert("최대인원를 입력하세요.");
		join_frm.j_maxmem.focus();
		return;
	} 
	
	if(join_frm.j_title.value.length == 0){	
		alert("제목을 입력하세요.");
		join_frm.j_title.focus();
		return;
	} 
	if(join_frm.j_content.value.length == 0){	
		alert("내용을 입력하세요.");
		join_frm.j_content.focus();
		return;
	} 
	if(join_frm.j_pwd.value.length == 0){	
		alert("암호를 입력하세요.");
		join_frm.j_pwd.focus();
		return;
	} 
	
	document.join_frm.submit();
	// if문에 충족하지 않으면 form에 있는 action으로 submit 하겠다.
}

function delete_ok() {
	if(del_form.j_pwd.value.length == 0){	
		alert("비밀번호를 입력하세요.");
		del_form.j_pwd.focus();
		return;
	} 
	document.del_form.submit();
}