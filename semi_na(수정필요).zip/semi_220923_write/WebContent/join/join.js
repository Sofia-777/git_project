function check_ok() {
	if(join_frm.j_title.value.length == 0){	
		alert("제목을 입력하세요.");
		join_frm.b_title.focus();
		return;
	} 
	
	if(join_frm.j_content.value.length == 0){	
		alert("글 내용을 입력하세요.");
		wrt_frm.b_content.focus();
		return;
	} 
	
	if(join_frm.j_pwd.value.length == 0){	
		alert("비밀번호를 입력하세요.");
		wrt_frm.b_pwd.focus();
		return;
	} 
	
	document.join_frm.submit();
	// if문에 충족하지 않으면 form에 있는 action으로 submit 하겠다.
}

function delete_ok() {
	if(del_form.b_pwd.value.length == 0){	
		alert("비밀번호를 입력하세요.");
		del_form.b_pwd.focus();
		return;
	} 
	document.del_form.submit();
	// if문에 충족하지 않으면 form에 있는 action으로 submit 하겠다.
	
}

function replyEdit_ok() {
	if(reply_frm.b_id == u_id){	
		alert("수정이 가능합니다.");
		document.reply_frm.submit();
		return;
	}
	
	
function application_ok() {
		alert("즐거운 취미생활을 공유하세요!");
}