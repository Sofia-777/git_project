package semi_boardComment;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;



public class BoardCommentDBBean {

	private static BoardCommentDBBean instance = new BoardCommentDBBean();
	
//	전역 BoardCommentBean 객체 레퍼런스를 리턴하는 메소드
	public static BoardCommentDBBean getInstance() {
		return instance;
	}
	 
//	쿼리작업에 사용할 커넥션 객체를 리턴하는 메소드
	public Connection getConnection() throws Exception {
		Context ctx = new InitialContext();
		DataSource ds = (DataSource)ctx.lookup("java:comp/env/jdbc/oracle");
		return ds.getConnection();
	}
	
//	전달인자로 받은 comment를 SEMI_BOARDCOMMENT 테이블에 삽입하는 메소드
	public int insertComment(BoardCommentBean comment) throws Exception{
		int re = -1;
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql="SELECT MAX(BC_IDX) FROM SEMI_BOARDCOMMENT";
//		댓글 번호 순서(프라이머리 키로서 대댓글을 위한 고유 번호)를 위한 쿼리로 제일 큰 값을 찾는다.
		int number=1;
//		댓글 테이블에 데이터가 없을 시 번호 1을 부여
		int idx = comment.getBc_idx();
		int ref = comment.getBc_ref();
		int step = comment.getBc_step();
		int level = comment.getBc_level();
//		대댓글 또는 신규 댓글임을 구분하기 위해 bc_idx값을 들고옴
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
//			최대값을 찾은 쿼리 결과를 rs에 저장
			if(rs.next()) {
				number=rs.getInt("MAX(BC_IDX)")+1;
			// 결과값이 있는 경우 rs에서 값을 받아와 +1을 한 뒤 그 번호를 number에 저장한다.
			} else {
				number = 1;
			}
			
			// 대댓글인지 아닌지 확인 여부, 대댓글 일 때 이미 받아온 bc_idx 값이 존재할 것이므로
			if (idx != 0) {
				sql="UPDATE SEMI_BOARDCOMMENT SET BC_STEP=BC_STEP+1 WHERE BC_REF=? AND BC_STEP > ?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, ref);
				pstmt.setInt(2, step);
				pstmt.executeUpdate();
				step = step+1;
				level = level+1;
			} else {
				ref = number;
				step = 0;
				level = 0;
			}

			
				sql="INSERT INTO SEMI_BOARDCOMMENT VALUES(?, ?, ?, ?, ?, sysdate, ?, ?, ?)";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, number);
				pstmt.setInt(2, comment.getBc_bidx());
				pstmt.setString(3, comment.getBc_id());
				pstmt.setString(4, comment.getBc_nickname());
				pstmt.setString(5, comment.getBc_content());
				pstmt.setInt(6, comment.getBc_ref());
				pstmt.setInt(7, comment.getBc_step());
				pstmt.setInt(8, comment.getBc_level());
				pstmt.executeUpdate();

			re = 1;
		}catch(SQLException ex) {
			System.out.println("추가실패");
			ex.printStackTrace();
		}		
		finally {
			try{
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(Exception e){
				e.printStackTrace();
			}
		} 
		return re;
	}
	
	public ArrayList<BoardCommentBean> listComment(int idx) throws Exception{
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql="SELECT bc_bidx\r\n" + 
				" 	     , bc_id\r\n" + 
				"  	     , bc_nickname\r\n" + 
				"  	     , bc_content\r\n" + 
				"  	     , bc_date \r\n" + 
				   "  FROM SEMI_BOARDCOMMENT \r\n" + 
				"    WHERE bc_bidx = ?\r\n" + 
				" ORDER BY bc_date";
		ArrayList<BoardCommentBean> commentList = new ArrayList<BoardCommentBean>();
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, idx);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				BoardCommentBean comment = new BoardCommentBean();
				comment.setBc_bidx(rs.getInt(1));				
				comment.setBc_id(rs.getString(2));				
				comment.setBc_nickname(rs.getString(3));				
				comment.setBc_content(rs.getString(4));				
				comment.setBc_date(rs.getTimestamp(5));				
				
				commentList.add(comment);
			}
		}catch(SQLException ex) {
			System.out.println("추가실패");
			ex.printStackTrace();
		}		
		finally {
			try{
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(Exception e){
				e.printStackTrace();
			}
		} 
		return commentList;
	}
	
	// 리턴타입이 BoardCommentBean인 getBoardComment(), 
	// 매개변수 글번호를 통해 작성자~글내용까지 BoardCommentBean에 담아서 리턴
		public BoardCommentBean getBoardComment(int bc_idx) throws Exception{
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			BoardCommentBean comment = new BoardCommentBean();
			String sql = "";

			
			try {
				conn = getConnection();							
				sql ="	 SELECT BC_IDX\r\n" + 
						"     , BC_BIDX\r\n" + 
						"     , BC_ID\r\n" + 
						"     , BC_NICKNAME\r\n" + 
						"     , BC_CONTENT\r\n" + 
						"     , BC_DATE\r\n" + 
						"     , BC_REF\r\n" + 
						"     , BC_STEP\r\n" + 
						"     , BC_LEVEL\r\n" + 
						"  FROM SEMI_BOARDCOMMENT\r\n" + 
						" WHERE BC_IDX = ?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, bc_idx); 
				rs = pstmt.executeQuery();
					
			if(rs.next()) {
				comment.setBc_idx(rs.getInt("bc_idx"));
				comment.setBc_bidx(rs.getInt("bc_bidx"));
				comment.setBc_id(rs.getString("bc_id"));
				comment.setBc_nickname(rs.getString("bc_nickname"));
				comment.setBc_content(rs.getString("bc_content"));
				comment.setBc_date(rs.getTimestamp("bc_date"));
				comment.setBc_ref(rs.getInt("bc_ref"));
				comment.setBc_step(rs.getInt("bc_step"));
				comment.setBc_level(rs.getInt("bc_level"));
				}
			
				
			}catch(SQLException ex) {
				System.out.println("추가 실패");
				ex.printStackTrace();
			}		
			finally {
				try{
					if(pstmt != null) pstmt.close();
					if(conn != null) conn.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			} 
			return comment;
		}
		

}
