package semi_boardComment;

import java.sql.Timestamp;

public class BoardCommentBean {
	private int bc_idx;
	private int bc_bidx;
	private String bc_id;
	private String bc_nickname;
	private String bc_content;
	private Timestamp bc_date;
	private int bc_ref;
	private int bc_step;
	public int getBc_idx() {
		return bc_idx;
	}
	public void setBc_idx(int bc_idx) {
		this.bc_idx = bc_idx;
	}
	private int bc_level;

	public int getBc_ref() {
		return bc_ref;
	}
	public void setBc_ref(int bc_ref) {
		this.bc_ref = bc_ref;
	}
	public int getBc_step() {
		return bc_step;
	}
	public void setBc_step(int bc_step) {
		this.bc_step = bc_step;
	}
	public int getBc_level() {
		return bc_level;
	}
	public void setBc_level(int bc_level) {
		this.bc_level = bc_level;
	}
	public int getBc_bidx() {
		return bc_bidx;
	}
	public void setBc_bidx(int bc_bidx) {
		this.bc_bidx = bc_bidx;
	}
	public String getBc_id() {
		return bc_id;
	}
	public void setBc_id(String bc_id) {
		this.bc_id = bc_id;
	}
	public String getBc_nickname() {
		return bc_nickname;
	}
	public void setBc_nickname(String bc_nickname) {
		this.bc_nickname = bc_nickname;
	}
	public String getBc_content() {
		return bc_content;
	}
	public void setBc_content(String bc_content) {
		this.bc_content = bc_content;
	}
	public Timestamp getBc_date() {
		return bc_date;
	}
	public void setBc_date(Timestamp bc_date) {
		this.bc_date = bc_date;
	}
	
	
}
