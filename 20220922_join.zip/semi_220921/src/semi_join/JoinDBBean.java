package semi_join;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import semi_board.BoardBean;
import semi_board.BoardDBBean;



public class JoinDBBean {
	// 작성자 : 김나영 
	// 날짜 : 2022.09.22
	//한글 깨진 현상 발생
	
	
	//�쟾�뿭 BoardBean 媛앹껜 �젅�띁�윴�뒪瑜� 由ы꽩�븯�뒗 硫붿냼�뱶
	private static JoinDBBean instance = new JoinDBBean();
	
	public static JoinDBBean getInstance() {
		return instance;
	}
	
//	荑쇰━�옉�뾽�뿉 �궗�슜�븷 而ㅻ꽖�뀡 媛앹껜瑜� 由ы꽩�븯�뒗 硫붿냼�뱶	 
	public Connection getConnection() throws Exception {
		Context ctx = new InitialContext();
		DataSource ds = (DataSource)ctx.lookup("java:comp/env/jdbc/oracle");
		return ds.getConnection();
	}
	
//	�쟾�떖�씤�옄濡� 諛쏆� board瑜� SEMI_BOARDTABLE �뀒�씠釉붿뿉 �궫�엯�븯�뒗 硫붿냼�뱶
	public int insertJoin(JoinBean join) throws Exception{
		int re = -1;
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql="SELECT MAX(j_idx) FROM SEMI_JOINTABLE";
		// 湲�踰덊샇 �닚�꽌瑜� �쐞�븳 荑쇰━濡� 湲�踰덊샇 以� �젣�씪 �겙 媛믪쓣 李얜뒗�떎.
		int number=1;
		// 1濡� �떆�옉�빐�빞 寃곌낵媛믪씠 �뾾�쓣 �븣(�뀒�씠釉붿뿉 �뜲�씠�꽣媛� �뾾�쓣 �떆) 踰덊샇 1�씠 遺��뿬�맂�떎.
		int idx = join.getJ_idx();
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			// 理쒕�媛믪쓣 李얠� 寃곌낵瑜� rs�뿉 ���옣�븳�떎.
			if(rs.next()) {
				number=rs.getInt("MAX(j_idx)")+1;
			// 寃곌낵媛믪씠 �엳�뒗 寃쎌슦 rs�뿉�꽌 媛믪쓣 諛쏆븘�� +1�쓣 �븳 �뮘 洹� 踰덊샇瑜� number�뿉 ���옣�븳�떎.
			} else {
				number = 1;
			}
			
			//18개의 칼럼
			System.out.println("@@@### re ===> "+number);
			System.out.println("@@@### getJ_recruit ===> "+join.getJ_recruit());
			System.out.println("@@@### getJ_id() ===> "+join.getJ_id());
			System.out.println("@@@### getJ_nickname ===> "+join.getJ_nickname());
			System.out.println("@@@### getJ_city ===> "+join.getJ_city());
			System.out.println("@@@### getJ_location ===> "+join.getJ_location());//
			System.out.println("@@@### getJ_hobbyB ===> "+join.getJ_hobbyB());  
			System.out.println("@@@### getJ_hobbyS ===> "+join.getJ_hobbyS());
			System.out.println("@@@### getJ_title ===> "+join.getJ_title());
			System.out.println("@@@### getJ_date ===> "+join.getJ_date());
			System.out.println("@@@### getJ_Mday ===> "+join.getJ_Dday());//
			System.out.println("@@@### getJ_Mday ===> "+join.getJ_Mday()); 
			System.out.println("@@@### getJ_count ===> "+join.getJ_count());
			System.out.println("@@@### getJ_cost ===> "+join.getJ_cost());
			System.out.println("@@@### getJ_maxmem ===> "+join.getJ_maxmem());
			System.out.println("@@@### getJ_nowmem ===> "+join.getJ_nowmem()); //
			System.out.println("@@@### getJ_content ===> "+join.getJ_content());
			System.out.println("@@@### getJ_pwd ===> "+join.getJ_pwd());
			

			sql="INSERT INTO SEMI_JOINTABLE VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ,?, ?, ?, ?, ?, ?)";
			
			//18개의 칼럼
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, number); 			
			pstmt.setString(2, join.getJ_recruit()); 
			pstmt.setString(3, join.getJ_id()); 
			pstmt.setString(4, join.getJ_nickname());
			pstmt.setString(5, join.getJ_city()); 
			pstmt.setString(6, join.getJ_location()); 
			pstmt.setString(7, join.getJ_hobbyB()); 
			pstmt.setString(8, join.getJ_hobbyS()); 
			pstmt.setString(9, join.getJ_title()); 
			pstmt.setTimestamp(10, join.getJ_date()); 
			pstmt.setString(11, join.getJ_Dday()); 
			pstmt.setString(12, join.getJ_Mday()); 
			pstmt.setInt(13, join.getJ_count()); 
			pstmt.setString(14, join.getJ_cost()); 
			pstmt.setInt(15, join.getJ_maxmem()); 
			pstmt.setInt(16, join.getJ_nowmem()); 
			pstmt.setString(17, join.getJ_content()); 
			pstmt.setString(18, join.getJ_pwd()); 
			pstmt.executeUpdate();
			
			re = 1;
		}catch(SQLException ex) {
			System.out.println("異붽��떎�뙣");
			ex.printStackTrace();
		}		
		finally {
			try{
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(Exception e){
				e.printStackTrace();
			}
		} 
		return re;
	}
	
//	由ы꽩���엯�씠 ArrayList �젣�꽕由� �뙆�씪誘명꽣 由ы꽩媛믪� BoardBean�씤 listBoard 硫붿냼�뱶
//	�럹�씠吏� �꽆踰꾨�� 留ㅺ컻蹂��닔濡� 諛쏆븘 �럹�씠吏뺤씠 異붿쟻�릺寃� �븿
	public ArrayList<JoinBean> listBoard(String pageNumber) throws Exception{
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		ResultSet pageSet = null;
		int dbCount = 0;
//		db�뿉 ���옣�맂 珥� 湲��쓽 媛쒖닔瑜� 荑쇰━臾몄쑝濡� 遺덈윭�� �떞�쓣 蹂��닔 �깮�꽦
		int absolutePage = 1;
		
		String sql= "SELECT j_idx\r\n" + 
					"     , j_recruit\r\n" + 
					"     , j_id\r\n" + 
					"     , j_nickname\r\n" + 
					"     , j_city\r\n" + 
					"     , j_location\r\n" + 
					"     , j_hobbyB\r\n" + 
					"     , j_hobbyS\r\n" + 
					"     , j_title\r\n" + 
					"     , j_date\r\n" + 
					"     , j_Dday\r\n" + 
					"     , j_Mday\r\n" + 
					"     , j_count\r\n" + 
					"     , j_cost\r\n" + 
					"     , j_maxmem\r\n" + 
					"     , j_nowmem\r\n" + 
					"     , j_content\r\n" + 
					"     , j_pwd\r\n" + 
					"  FROM SEMI_JOINTABLE\r\n" + 
					" ORDER BY j_idx desc";
		
		String sql2= "SELECT COUNT(j_idx) FROM SEMI_JOINTABLE";
		ArrayList<JoinBean> list = new ArrayList<JoinBean>();
		
		try {
			conn = getConnection();
			stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
//			而ㅼ꽌瑜� �듅�젙 �쐞移섎줈 �씠�룞�떆�궎湲� �쐞�븿
			pageSet = stmt.executeQuery(sql2);
			
			if (pageSet.next()) {
				dbCount = pageSet.getInt(1);
				pageSet.close();
			}
			
			if (dbCount % BoardBean.pageSize == 0) {
				BoardBean.pageCount = dbCount / BoardBean.pageSize;
				
			} else {
				BoardBean.pageCount = dbCount / BoardBean.pageSize + 1;
//				珥� 湲��쓽 媛쒖닔�뿉�꽌 愿�由ъ옄媛� 吏��젙�븳 pagesize濡� �굹�댋�쓣 �븣 �굹癒몄�媛� �엳�쑝硫�
//				紐レ쓽 媛믪뿉�꽌 �럹�씠吏�媛� �븯�굹 �뜑 異붽��릺�뼱�빞 �븯誘�濡�
			}
			
//			癒몃Ъ�뜕 �럹�씠吏�濡� �룎�븘媛�湲� �쐞�븳 if臾�
			if (pageNumber != null) {
				BoardBean.pageNum = Integer.parseInt(pageNumber);
				absolutePage = (BoardBean.pageNum - 1) * BoardBean.pageSize + 1;
				// �삁瑜� �뱾�뼱 �븳 �럹�씠吏��떦 10媛쒖쓽 湲� 湲곗� 1�럹�씠吏��뿏 1~10湲��씠, 
				// 2�럹�씠吏��뿏 11~20�씠 臾띠쓬�씠 �릺誘�濡� �궗�슜�옄媛� 3�럹�씠吏��뿉 癒몃Ъ怨� �엳�뿀�쓣 �븣
				// (3-1)*10+1=21�쓽 媛믪씠 �굹�삤�뒗�뜲
				// 3�럹�씠吏� 泥� �떆�옉 湲��씠 21�씠誘�濡� �씠�윴 �떇�쓽 �뙆�씪�읉�씠 媛��뒫.
			}
			rs = stmt.executeQuery(sql);
			
			if (rs.next()) {
				rs.absolute(absolutePage);
//				而ㅼ꽌瑜� �듅�젙 �쐞移섎줈 �씠�룞�떆�궎湲� �쐞�븳 硫붿냼�뱶
				int count = 0;
					while(count < JoinBean.pageSize) {
						JoinBean join = new JoinBean();
					
					join.setJ_idx(rs.getInt(1));
					join.setJ_recruit(rs.getString(2));
					join.setJ_id(rs.getString(3));
					join.setJ_nickname(rs.getString(4));
					join.setJ_city(rs.getString(5));
					join.setJ_location (rs.getString(6));
					join.setJ_hobbyB (rs.getString(7));
					join.setJ_hobbyS(rs.getString(8));
					join.setJ_title(rs.getString(9));
					join.setJ_date(rs.getTimestamp(10));
					join.setJ_Dday (rs.getString(11));
					join.setJ_Mday(rs.getString(12));
					join.setJ_count(rs.getInt(13));
					join.setJ_cost(rs.getString(14));
					join.setJ_maxmem (rs.getInt(15));
					join.setJ_nowmem(rs.getInt(16));
					join.setJ_content(rs.getString(17));
					join.setJ_pwd(rs.getString(18));
					
					list.add(join);
					
					if (rs.isLast()) {
						break;
					} else {
						rs.next();
					}
					
					count++;
//					count媛� 利앷��븯�뿬 pagesize�겕湲� �쟾源뚯� 異쒕젰 諛섎났
				}
			}
		}catch(SQLException ex) {
			System.out.println("異붽��떎�뙣");
			ex.printStackTrace();
		}		
		finally {
			try{
				if(stmt != null) stmt.close();
				if(conn != null) conn.close();
			}catch(Exception e){
				e.printStackTrace();
			}
		} 
		return list;
	}
	
	// 由ы꽩���엯�씠 BoardBean�씤 getBoard(), 
	// 留ㅺ컻蹂��닔 湲�踰덊샇瑜� �넻�빐 �옉�꽦�옄~湲��궡�슜源뚯� BoardBean�뿉 �떞�븘�꽌 由ы꽩
	//	�닔�젙 �떆 議고쉶�닔 移댁슫�똿 諛⑹�瑜� �쐞�븳 boolean 留ㅺ컻蹂��닔 異붽�
		public JoinBean getBoard(int j_idx, Boolean hit) throws Exception{
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			JoinBean join = new JoinBean();
			String sql = "";

			
			try {
				conn = getConnection();
				if(hit == true) {
				sql = "UPDATE SEMI_JOINTABLE SET j_count = j_count+1 WHERE j_idx = ?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, j_idx); 
				pstmt.executeUpdate();
				pstmt.close();
				
				sql ="		SELECT j_idx\r\n" + 
						"     , j_recruit\r\n" + 
						"     , j_id\r\n" + 
						"     , j_nickname\r\n" + 
						"     , j_city\r\n" + 
						"     , j_location\r\n" + 
						"     , j_hobbyB\r\n" + 
						"     , j_hobbyS\r\n" + 
						"     , j_title\r\n" + 
						"     , j_date\r\n" + 
						"     , j_Dday\r\n" + 
						"     , j_Mday\r\n" + 
						"     , j_count\r\n" + 
						"     , j_cost\r\n" + 
						"     , j_maxmem\r\n" + 
						"     , j_nowmem\r\n" + 
						"     , j_content\r\n" + 
						"     , j_pwd\r\n" + 
						"  FROM SEMI_JOINTABLE\r\n" +
						" WHERE j_idx = ?";
				
				
				 
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, j_idx); 
				rs = pstmt.executeQuery();
				} else {
					sql ="		SELECT j_idx\r\n" + 
							"     , j_recruit\r\n" + 
							"     , j_id\r\n" + 
							"     , j_nickname\r\n" + 
							"     , j_city\r\n" + 
							"     , j_location\r\n" + 
							"     , j_hobbyB\r\n" + 
							"     , j_hobbyS\r\n" + 
							"     , j_title\r\n" + 
							"     , j_date\r\n" + 
							"     , j_Dday\r\n" + 
							"     , j_Mday\r\n" + 
							"     , j_count\r\n" + 
							"     , j_cost\r\n" + 
							"     , j_maxmem\r\n" + 
							"     , j_nowmem\r\n" + 
							"     , j_content\r\n" + 
							"     , j_pwd\r\n" + 
							"  FROM SEMI_JOINTABLE\r\n" +
							" WHERE j_idx = ?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, j_idx); 
				rs = pstmt.executeQuery();					
				}
								
			if(rs.next()) {
				join.setJ_idx(rs.getInt("j_idx"));
				join.setJ_recruit(rs.getString("j_recruit"));
				join.setJ_id(rs.getString("j_id"));
				join.setJ_nickname(rs.getString("j_nickname"));
				join.setJ_city(rs.getString("j_city"));
				join.setJ_location (rs.getString("j_location"));
				join.setJ_hobbyB (rs.getString("j_hobbyB"));
				join.setJ_hobbyS(rs.getString("j_hobbyS"));
				join.setJ_title(rs.getString("j_title"));
				join.setJ_date(rs.getTimestamp("j_date"));
				join.setJ_Dday (rs.getString("j_Dday"));
				join.setJ_Mday(rs.getString("j_Mday"));
				join.setJ_count(rs.getInt("j_count"));
				join.setJ_cost(rs.getString("j_cost"));
				join.setJ_maxmem (rs.getInt("j_maxmem"));
				join.setJ_nowmem(rs.getInt("j_nowmem"));
				join.setJ_content(rs.getString("j_content"));
				join.setJ_pwd(rs.getString("j_pwd"));
				}
			
			}catch(SQLException ex) {
				System.out.println("占쌩곤옙 占쏙옙占쏙옙");
				ex.printStackTrace();
			}		
			finally {
				try{
					if(pstmt != null) pstmt.close();
					if(conn != null) conn.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			} 
			return join;
		}
		
		
		//일단 여기까지 작성함. 글쓰기랑 부분 함 보고올게용. 
		
		
		
//		湲� �궘�젣 硫붿냼�뱶
		// BoardDBBean.java에서는
		//public int deleteJoin(int idx, String pwd) throws Exception {로 작성해주셨는데 일단 혹시 모르니깐  그대로 사용할게용
		
		
		public int deleteJoin(int idx, String pwd) throws Exception {
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			int result = -1;
			
			try {
				conn = getConnection();
				String sql="SELECT j_pwd FROM SEMI_JOINTABLE WHERE j_idx = ?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, idx); 
				rs = pstmt.executeQuery();
				
				if(rs.next()) {
					if(rs.getString("j_pwd").equals(pwd)) {
						sql="DELETE FROM SEMI_JOINTABLE WHERE j_idx = ?";
						pstmt = conn.prepareStatement(sql);
						pstmt.setInt(1, idx);
						pstmt.executeUpdate();	
						
						result = 1;
					} else {
						result = 2;
					}
				}				
				
			}catch(SQLException ex) {
				System.out.println("�궘�젣 �떎�뙣");
				ex.printStackTrace();
			}		
			finally {
				try{
					if(pstmt != null) pstmt.close();
					if(conn != null) conn.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			} 
			return result;			
		}
		
//		湲� �닔�젙�븯�뒗 硫붿냼�뱶
		public int editJoin(JoinBean join) throws Exception {

			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			int result = -1;
			
			try {
				conn = getConnection();
				String sql="SELECT j_pwd FROM SEMI_JOINTABLE WHERE j_idx = ?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, join.getJ_idx()); 
				rs = pstmt.executeQuery();
				
				if(rs.next()) {
					if(rs.getString("j_pwd").equals(join.getJ_pwd())) {
						//업데이트 쿼리문 및 if 문에 따라서 j_recruit을 넣어야 하는지 넣지 말아야하는지 몰라서.ㅠ 일단 넣어놓을게요ㅠ -- 김나영
						// 잠시 스탑 9.22 먼저 글 삽입부터 시도 해봐야함(민지언니가 내역 가지고 와야해서)
						
						sql="UPDATE SEMI_JOINTABLE SET  j_recruit=?\r\n" + 
									"                 , j_id=?\r\n" + 
									"                 , j_nickname=?\r\n" + 
									"                 , j_city=?\r\n" + 
									"                 , j_location=?\r\n" + 
									"                 , j_hobbyB=?\r\n" + 
									"                 , j_hobbyS=?\r\n" + 
									"                 , j_title=?\r\n" + 
									"                 , j_date=?\r\n" + 
									"                 , j_Dday=?\r\n" + 
									"                 , j_Mday=?\r\n" + 
									"                 , j_count=?\r\n" + 
									"                 , j_cost=?\r\n" + 
									"                 , j_maxmem=?\r\n" + 
									"                 , j_nowmem=?\r\n" + 
									"                 , j_content=?\r\n" + 
									"             WHERE j_idx = ?";
						pstmt = conn.prepareStatement(sql);
//						pstmt.setString(1, board.getB_id());
//						pstmt.setString(2, board.getB_nickname());
//						pstmt.setString(3, board.getB_title());
//						pstmt.setString(4, board.getB_content());
//						pstmt.setInt(5, board.getB_idx());
//						pstmt.executeUpdate();	
//						
						result = 1;
					} else {
						result = 2;
					}
				}				
				
			}catch(SQLException ex) {
				System.out.println("�닔�젙 �떎�뙣");
				ex.printStackTrace();
			}		
			finally {
				try{
					if(pstmt != null) pstmt.close();
					if(conn != null) conn.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			} 
			return result;				
		}	
	
}
