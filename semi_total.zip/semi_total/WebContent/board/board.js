
function check_ok() {
	if(wrt_frm.b_nickname.value.length == 0){	
		alert("작성자를 입력하세요.");
		wrt_frm.b_nickname.focus();
		return;
	} 
	
	if(wrt_frm.b_title.value.length == 0){	
		alert("제목을 입력하세요.");
		wrt_frm.b_title.focus();
		return;
	} 
	
	if(wrt_frm.b_content.value.length == 0){	
		alert("글 내용을 입력하세요.");
		wrt_frm.b_content.focus();
		return;
	} 
	
	if(wrt_frm.b_pwd.value.length == 0){	
		alert("비밀번호를 입력하세요.");
		wrt_frm.b_pwd.focus();
		return;
	} 
	
	document.wrt_frm.submit();
	// if문에 충족하지 않으면 form에 있는 action으로 submit 하겠다.
}

function delete_ok() {
	if(del_form.b_pwd.value.length == 0){	
		alert("비밀번호를 입력하세요.");
		del_form.b_pwd.focus();
		return;
	} 
	document.del_form.submit();
	// if문에 충족하지 않으면 form에 있는 action으로 submit 하겠다.
	
}

function comment_ok() {
	if(reply_frm.bc_content.value.length == 0){	
		alert("댓글 내용을 입력하세요.");
		return;
	} 
	document.reply_frm.submit();
}