package semi_boardComment;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;



public class BoardCommentDBBean {

	private static BoardCommentDBBean instance = new BoardCommentDBBean();
	
//	�쟾�뿭 BoardCommentBean 媛앹껜 �젅�띁�윴�뒪瑜� 由ы꽩�븯�뒗 硫붿냼�뱶
	public static BoardCommentDBBean getInstance() {
		return instance;
	}
	 
//	荑쇰━�옉�뾽�뿉 �궗�슜�븷 而ㅻ꽖�뀡 媛앹껜瑜� 由ы꽩�븯�뒗 硫붿냼�뱶
	public Connection getConnection() throws Exception {
		Context ctx = new InitialContext();
		DataSource ds = (DataSource)ctx.lookup("java:comp/env/jdbc/oracle");
		return ds.getConnection();
	}
	
//	�쟾�떖�씤�옄濡� 諛쏆� comment瑜� SEMI_BOARDCOMMENT �뀒�씠釉붿뿉 �궫�엯�븯�뒗 硫붿냼�뱶
	public int insertComment(BoardCommentBean comment) throws Exception{
		int re = -1;
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql="SELECT MAX(BC_IDX) FROM SEMI_BOARDCOMMENT";
//		�뙎湲� 踰덊샇 �닚�꽌(�봽�씪�씠癒몃━ �궎濡쒖꽌 ���뙎湲��쓣 �쐞�븳 怨좎쑀 踰덊샇)瑜� �쐞�븳 荑쇰━濡� �젣�씪 �겙 媛믪쓣 李얜뒗�떎.
		int number=1;
//		�뙎湲� �뀒�씠釉붿뿉 �뜲�씠�꽣媛� �뾾�쓣 �떆 踰덊샇 1�쓣 遺��뿬
		int idx = comment.getBc_idx();
		int ref = comment.getBc_ref();
		int step = comment.getBc_step();
		int level = comment.getBc_level();
//		���뙎湲� �삉�뒗 �떊洹� �뙎湲��엫�쓣 援щ텇�븯湲� �쐞�빐 bc_idx媛믪쓣 �뱾怨좎샂
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
//			理쒕�媛믪쓣 李얠� 荑쇰━ 寃곌낵瑜� rs�뿉 ���옣
			if(rs.next()) {
				number=rs.getInt("MAX(BC_IDX)")+1;
			// 寃곌낵媛믪씠 �엳�뒗 寃쎌슦 rs�뿉�꽌 媛믪쓣 諛쏆븘�� +1�쓣 �븳 �뮘 洹� 踰덊샇瑜� number�뿉 ���옣�븳�떎.
			} else {
				number = 1;
			}
			
			// ���뙎湲��씤吏� �븘�땶吏� �솗�씤 �뿬遺�, ���뙎湲� �씪 �븣 �씠誘� 諛쏆븘�삩 bc_idx 媛믪씠 議댁옱�븷 寃껋씠誘�濡�
			if (idx != 0) {
				sql="UPDATE SEMI_BOARDCOMMENT SET BC_STEP=BC_STEP+1 WHERE BC_REF=? AND BC_STEP > ?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, ref);
				pstmt.setInt(2, step);
				pstmt.executeUpdate();
				step = step+1;
				level = level+1;
			} else {
				ref = number;
				step = 0;
				level = 0;
			}

			
				sql="INSERT INTO SEMI_BOARDCOMMENT VALUES(?, ?, ?, ?, ?, sysdate, ?, ?, ?)";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, number);
				pstmt.setInt(2, comment.getBc_bidx());
				pstmt.setString(3, comment.getBc_id());
				pstmt.setString(4, comment.getBc_nickname());
				pstmt.setString(5, comment.getBc_content());
				pstmt.setInt(6, comment.getBc_ref());
				pstmt.setInt(7, comment.getBc_step());
				pstmt.setInt(8, comment.getBc_level());
				pstmt.executeUpdate();

			re = 1;
		}catch(SQLException ex) {
			System.out.println("추가 실패");
			ex.printStackTrace();
		}		
		finally {
			try{
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(Exception e){
				e.printStackTrace();
			}
		} 
		return re;
	}
	
	public ArrayList<BoardCommentBean> listComment(int idx, String pageNumber) throws Exception{
		Connection conn = null;
		Statement stmt = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ResultSet pageSet = null;
		int dbCount = 0;
		
		int absolutePage = 1;
		
		String sql="SELECT bc_idx\r\n" + 
				" 	     , bc_bidx\r\n" + 
				" 	     , bc_id\r\n" + 
				"  	     , bc_nickname\r\n" + 
				"  	     , bc_content\r\n" + 
				"  	     , bc_date \r\n" + 
				   "  FROM SEMI_BOARDCOMMENT \r\n" + 
				"    WHERE bc_bidx = ?\r\n" + 
				" ORDER BY bc_date";
		
		String sql2 = "SELECT COUNT(bc_idx) FROM SEMI_BOARDCOMMENT WHERE BC_BIDX = ?";
		ArrayList<BoardCommentBean> commentList = new ArrayList<BoardCommentBean>();
		
		try {
			conn = getConnection();
			stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
			pstmt = conn.prepareStatement(sql);
			// 여기서부터 작업하시오제발
			pstmt.setInt(1, idx);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				BoardCommentBean comment = new BoardCommentBean();
				comment.setBc_idx(rs.getInt(1));				
				comment.setBc_bidx(rs.getInt(2));				
				comment.setBc_id(rs.getString(3));				
				comment.setBc_nickname(rs.getString(4));				
				comment.setBc_content(rs.getString(5));				
				comment.setBc_date(rs.getTimestamp(6));				
				
				commentList.add(comment);
			}
		}catch(SQLException ex) {
			System.out.println("불러오기 실패");
			ex.printStackTrace();
		}		
		finally {
			try{
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(Exception e){
				e.printStackTrace();
			}
		} 
		return commentList;
	}
	
	// 由ы꽩���엯�씠 BoardCommentBean�씤 getBoardComment(), 
	// 留ㅺ컻蹂��닔 湲�踰덊샇瑜� �넻�빐 �옉�꽦�옄~湲��궡�슜源뚯� BoardCommentBean�뿉 �떞�븘�꽌 由ы꽩
		public BoardCommentBean getBoardComment(int bc_idx) throws Exception{
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			BoardCommentBean comment = new BoardCommentBean();
			String sql = "";

			
			try {
				conn = getConnection();							
				sql ="	 SELECT BC_IDX\r\n" + 
						"     , BC_BIDX\r\n" + 
						"     , BC_ID\r\n" + 
						"     , BC_NICKNAME\r\n" + 
						"     , BC_CONTENT\r\n" + 
						"     , BC_DATE\r\n" + 
						"     , BC_REF\r\n" + 
						"     , BC_STEP\r\n" + 
						"     , BC_LEVEL\r\n" + 
						"  FROM SEMI_BOARDCOMMENT\r\n" + 
						" WHERE BC_IDX = ?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, bc_idx); 
				rs = pstmt.executeQuery();
					
			if(rs.next()) {
				comment.setBc_idx(rs.getInt("bc_idx"));
				comment.setBc_bidx(rs.getInt("bc_bidx"));
				comment.setBc_id(rs.getString("bc_id"));
				comment.setBc_nickname(rs.getString("bc_nickname"));
				comment.setBc_content(rs.getString("bc_content"));
				comment.setBc_date(rs.getTimestamp("bc_date"));
				comment.setBc_ref(rs.getInt("bc_ref"));
				comment.setBc_step(rs.getInt("bc_step"));
				comment.setBc_level(rs.getInt("bc_level"));
				}
			
				
			}catch(SQLException ex) {
				System.out.println("불러오기 실패");
				ex.printStackTrace();
			}		
			finally {
				try{
					if(pstmt != null) pstmt.close();
					if(conn != null) conn.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			} 
			return comment;
		}

		
//		댓글 삭제 메소드
		public int deleteComment(int idx) throws Exception {
			Connection conn = null;
			PreparedStatement pstmt = null;
			int result = -1;
			
			try {
				conn = getConnection();
				String sql="DELETE FROM SEMI_BOARDCOMMENT WHERE bc_idx = ?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, idx); 
				pstmt.executeUpdate();
				System.out.println(idx);
				
				result = 1;
			}catch(SQLException ex) {
				System.out.println("삭제 실패");
				ex.printStackTrace();
			}		
			finally {
				try{
					if(pstmt != null) pstmt.close();
					if(conn != null) conn.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			} 
			return result;			
		}
				

}
