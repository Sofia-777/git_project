package semi_board;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;


public class BoardDBBean {
//	�쟾�뿭 BoardBean 媛앹껜 �젅�띁�윴�뒪瑜� 由ы꽩�븯�뒗 硫붿냼�뱶
	private static BoardDBBean instance = new BoardDBBean();
	
	public static BoardDBBean getInstance() {
		return instance;
	}
	
//	荑쇰━�옉�뾽�뿉 �궗�슜�븷 而ㅻ꽖�뀡 媛앹껜瑜� 由ы꽩�븯�뒗 硫붿냼�뱶	 
	public Connection getConnection() throws Exception {
		Context ctx = new InitialContext();
		DataSource ds = (DataSource)ctx.lookup("java:comp/env/jdbc/oracle");
		return ds.getConnection();
	}
	
//	�쟾�떖�씤�옄濡� 諛쏆� board瑜� SEMI_BOARDTABLE �뀒�씠釉붿뿉 �궫�엯�븯�뒗 硫붿냼�뱶
	public int insertBoard(BoardBean board) throws Exception{
		int re = -1;
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql="SELECT MAX(b_idx) FROM SEMI_BOARDTABLE";
		// 湲�踰덊샇 �닚�꽌瑜� �쐞�븳 荑쇰━濡� 湲�踰덊샇 以� �젣�씪 �겙 媛믪쓣 李얜뒗�떎.
		int number=1;
		// 1濡� �떆�옉�빐�빞 寃곌낵媛믪씠 �뾾�쓣 �븣(�뀒�씠釉붿뿉 �뜲�씠�꽣媛� �뾾�쓣 �떆) 踰덊샇 1�씠 遺��뿬�맂�떎.
		int idx = board.getB_idx();
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			// 理쒕�媛믪쓣 李얠� 寃곌낵瑜� rs�뿉 ���옣�븳�떎.
			if(rs.next()) {
				number=rs.getInt("MAX(b_idx)")+1;
			// 寃곌낵媛믪씠 �엳�뒗 寃쎌슦 rs�뿉�꽌 媛믪쓣 諛쏆븘�� +1�쓣 �븳 �뮘 洹� 踰덊샇瑜� number�뿉 ���옣�븳�떎.
			} else {
				number = 1;
			}
			
			System.out.println("@@@### re ===> "+number);
			System.out.println("@@@### re ===> "+board.getB_id());
			System.out.println("@@@### re ===> "+board.getB_nickname());
			System.out.println("@@@### re ===> "+board.getB_title());
			System.out.println("@@@### re ===> "+board.getB_content());
			System.out.println("@@@### re ===> "+board.getB_date());
			System.out.println("@@@### re ===> "+board.getB_count());
			System.out.println("@@@### re ===> "+board.getB_pwd());
			sql="INSERT INTO SEMI_BOARDTABLE VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, number); 
			pstmt.setString(2, board.getB_id()); 
			pstmt.setString(3, board.getB_nickname());
			pstmt.setString(4, board.getB_title()); 
			pstmt.setString(5, board.getB_content()); 
			pstmt.setTimestamp(6, board.getB_date()); 
			pstmt.setInt(7, board.getB_count()); 
			pstmt.setString(8, board.getB_pwd()); 
			pstmt.executeUpdate();
			
			re = 1;
		}catch(SQLException ex) {
			System.out.println("異붽��떎�뙣");
			ex.printStackTrace();
		}		
		finally {
			try{
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(Exception e){
				e.printStackTrace();
			}
		} 
		return re;
	}
	
//	由ы꽩���엯�씠 ArrayList �젣�꽕由� �뙆�씪誘명꽣 由ы꽩媛믪� BoardBean�씤 listBoard 硫붿냼�뱶
//	�럹�씠吏� �꽆踰꾨�� 留ㅺ컻蹂��닔濡� 諛쏆븘 �럹�씠吏뺤씠 異붿쟻�릺寃� �븿
	public ArrayList<BoardBean> listBoard(String pageNumber) throws Exception{
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		ResultSet pageSet = null;
		int dbCount = 0;
//		db�뿉 ���옣�맂 珥� 湲��쓽 媛쒖닔瑜� 荑쇰━臾몄쑝濡� 遺덈윭�� �떞�쓣 蹂��닔 �깮�꽦
		int absolutePage = 1;
		
		String sql= "SELECT b_idx\r\n" + 
					"     , b_id\r\n" + 
					"     , b_nickname\r\n" + 
					"     , b_title\r\n" + 
					"     , b_content\r\n" + 
					"     , b_date\r\n" + 
					"     , b_count\r\n" + 
					"     , b_pwd\r\n" + 
					"  FROM SEMI_BOARDTABLE\r\n" + 
					" ORDER BY b_idx desc";
		
		String sql2= "SELECT COUNT(b_idx) FROM SEMI_BOARDTABLE";
		ArrayList<BoardBean> list = new ArrayList<BoardBean>();
		
		try {
			conn = getConnection();
			stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
//			而ㅼ꽌瑜� �듅�젙 �쐞移섎줈 �씠�룞�떆�궎湲� �쐞�븿
			pageSet = stmt.executeQuery(sql2);
			
			if (pageSet.next()) {
				dbCount = pageSet.getInt(1);
				pageSet.close();
			}
			
			if (dbCount % BoardBean.pageSize == 0) {
				BoardBean.pageCount = dbCount / BoardBean.pageSize;
				
			} else {
				BoardBean.pageCount = dbCount / BoardBean.pageSize + 1;
//				珥� 湲��쓽 媛쒖닔�뿉�꽌 愿�由ъ옄媛� 吏��젙�븳 pagesize濡� �굹�댋�쓣 �븣 �굹癒몄�媛� �엳�쑝硫�
//				紐レ쓽 媛믪뿉�꽌 �럹�씠吏�媛� �븯�굹 �뜑 異붽��릺�뼱�빞 �븯誘�濡�
			}
			
//			癒몃Ъ�뜕 �럹�씠吏�濡� �룎�븘媛�湲� �쐞�븳 if臾�
			if (pageNumber != null) {
				BoardBean.pageNum = Integer.parseInt(pageNumber);
				absolutePage = (BoardBean.pageNum - 1) * BoardBean.pageSize + 1;
				// �삁瑜� �뱾�뼱 �븳 �럹�씠吏��떦 10媛쒖쓽 湲� 湲곗� 1�럹�씠吏��뿏 1~10湲��씠, 
				// 2�럹�씠吏��뿏 11~20�씠 臾띠쓬�씠 �릺誘�濡� �궗�슜�옄媛� 3�럹�씠吏��뿉 癒몃Ъ怨� �엳�뿀�쓣 �븣
				// (3-1)*10+1=21�쓽 媛믪씠 �굹�삤�뒗�뜲
				// 3�럹�씠吏� 泥� �떆�옉 湲��씠 21�씠誘�濡� �씠�윴 �떇�쓽 �뙆�씪�읉�씠 媛��뒫.
			}
			rs = stmt.executeQuery(sql);
			
			if (rs.next()) {
				rs.absolute(absolutePage);
//				而ㅼ꽌瑜� �듅�젙 �쐞移섎줈 �씠�룞�떆�궎湲� �쐞�븳 硫붿냼�뱶
				int count = 0;
					while(count < BoardBean.pageSize) {
					BoardBean board = new BoardBean();
					
					board.setB_idx(rs.getInt(1));
					board.setB_id(rs.getString(2));
					board.setB_nickname(rs.getString(3));
					board.setB_title(rs.getString(4));
					board.setB_content(rs.getString(5));
					board.setB_date(rs.getTimestamp(6));
					board.setB_count(rs.getInt(7));
					board.setB_pwd(rs.getString(8));
					
					list.add(board);
					
					if (rs.isLast()) {
						break;
					} else {
						rs.next();
					}
					
					count++;
//					count媛� 利앷��븯�뿬 pagesize�겕湲� �쟾源뚯� 異쒕젰 諛섎났
				}
			}
		}catch(SQLException ex) {
			System.out.println("異붽��떎�뙣");
			ex.printStackTrace();
		}		
		finally {
			try{
				if(stmt != null) stmt.close();
				if(conn != null) conn.close();
			}catch(Exception e){
				e.printStackTrace();
			}
		} 
		return list;
	}
	
	// 由ы꽩���엯�씠 BoardBean�씤 getBoard(), 
	// 留ㅺ컻蹂��닔 湲�踰덊샇瑜� �넻�빐 �옉�꽦�옄~湲��궡�슜源뚯� BoardBean�뿉 �떞�븘�꽌 由ы꽩
	//	�닔�젙 �떆 議고쉶�닔 移댁슫�똿 諛⑹�瑜� �쐞�븳 boolean 留ㅺ컻蹂��닔 異붽�
		public BoardBean getBoard(int b_idx, Boolean hit) throws Exception{
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			BoardBean board = new BoardBean();
			String sql = "";

			
			try {
				conn = getConnection();
				if(hit == true) {
				sql = "UPDATE SEMI_BOARDTABLE SET b_count = b_count+1 WHERE b_idx = ?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, b_idx); 
				pstmt.executeUpdate();
				pstmt.close();
				
				sql ="	 SELECT b_idx\r\n" + 
						"     , b_id\r\n" + 
						"     , b_nickname\r\n" + 
						"     , b_title\r\n" + 
						"     , b_content\r\n" + 
						"     , b_date\r\n" + 
						"     , b_count\r\n" + 
						"     , b_pwd\r\n" + 
						"  FROM SEMI_BOARDTABLE\r\n" + 
						" WHERE b_idx = ?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, b_idx); 
				rs = pstmt.executeQuery();
				} else {
				sql ="	 SELECT b_idx\r\n" + 
						"     , b_id\r\n" + 
						"     , b_nickname\r\n" + 
						"     , b_title\r\n" + 
						"     , b_content\r\n" + 
						"     , b_date\r\n" + 
						"     , b_count\r\n" + 
						"     , b_pwd\r\n" + 
						"  FROM SEMI_BOARDTABLE\r\n" + 
						" WHERE b_idx = ?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, b_idx); 
				rs = pstmt.executeQuery();					
				}
								
			if(rs.next()) {
				board.setB_idx(rs.getInt("b_idx"));
				board.setB_id(rs.getString("b_id"));
				board.setB_nickname(rs.getString("b_nickname"));
				board.setB_title(rs.getString("b_title"));
				board.setB_content(rs.getString("b_content"));
				board.setB_date(rs.getTimestamp("b_date"));
				board.setB_count(rs.getInt("b_count"));
				board.setB_pwd(rs.getString("b_pwd"));
				}
			
			}catch(SQLException ex) {
				System.out.println("占쌩곤옙 占쏙옙占쏙옙");
				ex.printStackTrace();
			}		
			finally {
				try{
					if(pstmt != null) pstmt.close();
					if(conn != null) conn.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			} 
			return board;
		}
		
//		湲� �궘�젣 硫붿냼�뱶
		public int deleteBoard(int idx, String pwd) throws Exception {
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			int result = -1;
			
			try {
				conn = getConnection();
				String sql="SELECT b_pwd FROM SEMI_BOARDTABLE WHERE b_idx = ?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, idx); 
				rs = pstmt.executeQuery();
				
				if(rs.next()) {
					if(rs.getString("b_pwd").equals(pwd)) {
						sql="DELETE FROM SEMI_BOARDTABLE WHERE b_idx = ?";
						pstmt = conn.prepareStatement(sql);
						pstmt.setInt(1, idx);
						pstmt.executeUpdate();	
						
						result = 1;
					} else {
						result = 2;
					}
				}				
				
			}catch(SQLException ex) {
				System.out.println("�궘�젣 �떎�뙣");
				ex.printStackTrace();
			}		
			finally {
				try{
					if(pstmt != null) pstmt.close();
					if(conn != null) conn.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			} 
			return result;			
		}
		
//		게시글 수정 메소드
		public int editBoard(BoardBean board) throws Exception {

			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			int result = -1;
			
			try {
				conn = getConnection();
				String sql="SELECT b_pwd FROM SEMI_BOARDTABLE WHERE b_idx = ?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, board.getB_idx()); 
				rs = pstmt.executeQuery();
				
				if(rs.next()) {
					if(rs.getString("b_pwd").equals(board.getB_pwd())) {
						sql="UPDATE SEMI_BOARDTABLE SET b_id=?\r\n" + 
									"                 , b_nickname=?\r\n" + 
									"                 , b_title=?\r\n" + 
									"                 , b_content=? \r\n" + 
									"             WHERE b_idx = ?";
						pstmt = conn.prepareStatement(sql);
						pstmt.setString(1, board.getB_id());
						pstmt.setString(2, board.getB_nickname());
						pstmt.setString(3, board.getB_title());
						pstmt.setString(4, board.getB_content());
						pstmt.setInt(5, board.getB_idx());
						pstmt.executeUpdate();	
						
						result = 1;
					} else {
						result = 2;
					}
				}				
				
			}catch(SQLException ex) {
				System.out.println("수정 실패");
				ex.printStackTrace();
			}		
			finally {
				try{
					if(pstmt != null) pstmt.close();
					if(conn != null) conn.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			} 
			return result;				
		}	
}
